import asyncio
import fcntl
import json
import os
import random
import re
import shutil
import ssl
import sys
import tempfile
import threading
import time
import base64
import subprocess
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from glob import glob

import decky

PLUGIN_ROOT = Path(__file__).resolve().parent
if str(PLUGIN_ROOT) not in sys.path:
    sys.path.insert(0, str(PLUGIN_ROOT))

from backend.client import DaemonHttpClient


CHRONOGRAPH_MAX_SECONDS = (99 * 3600) + (59 * 60) + 59
PLAYTIME_REFRESH_SECONDS = 2.0

CUSTOM_ASSET_EXTENSIONS = frozenset({".png", ".gif", ".svg", ".jpg", ".jpeg", ".bmp"})
CUSTOM_ASSET_DIRECTORY_LIMIT = 24
CUSTOM_ASSET_PREVIEW_LIMIT_BYTES = 512 * 1024

# AI Agent(GPT/Codex)额度与会话监控,逻辑移植自 gpt_quota_monitor.py
AI_AGENT_USAGE_URL = "https://chatgpt.com/backend-api/wham/usage"
AI_AGENT_TOKEN_URL = "https://auth.openai.com/oauth/token"
AI_AGENT_CONVERSATIONS_URL = (
    "https://chatgpt.com/backend-api/conversations?offset=0&limit=20&order=updated"
)
AI_AGENT_DEFAULT_CLIENT_ID = "app_EMoamEEZ73f0CkXaXpYh7rann"
AI_AGENT_SESSION_ACTIVE_MINUTES = 5
AI_AGENT_USAGE_TTL_SECONDS = 600.0
AI_AGENT_WEB_TTL_SECONDS = 60.0
AI_AGENT_TOKENS_TTL_SECONDS = 300.0
AI_AGENT_SCREEN_REFRESH_MIN_SECONDS = 300.0
AI_AGENT_SCREEN_REFRESH_MAX_SECONDS = 720.0
AI_AGENT_UUID_RE = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
)
AI_AGENT_ACCOUNTS_FILENAME = "ai_agent_accounts.json"
AI_AGENT_ACCOUNTS_DIRNAME = "ai_agent_accounts"
AI_AGENT_LOGIN_URL_RE = re.compile(r"https://[^\s\"']+", re.IGNORECASE)
_ai_agent_usage_cache: dict = {}
_ai_agent_web_cache: dict = {"ts": 0.0, "items": []}
_ai_agent_tokens_cache: dict = {"ts": 0.0, "totals": None}
_ai_agent_login: dict = {"proc": None, "output": [], "auth_mtime": 0.0}
_ai_agent_ssl_context: ssl.SSLContext | None = None


def _ai_agent_https_context() -> ssl.SSLContext:
    """Decky 的 PyInstaller Python 默认 CA 路径失效，显式回落到系统 CA 包。"""
    global _ai_agent_ssl_context
    if _ai_agent_ssl_context is None:
        candidates = [os.environ.get("SSL_CERT_FILE", "").strip(),
                      "/etc/ssl/cert.pem",
                      "/etc/ssl/certs/ca-certificates.crt"]
        try:
            import certifi
            candidates.append(certifi.where())
        except Exception:
            pass
        for cafile in candidates:
            if cafile and os.path.isfile(cafile):
                _ai_agent_ssl_context = ssl.create_default_context(cafile=cafile)
                break
        else:
            _ai_agent_ssl_context = ssl.create_default_context()
    return _ai_agent_ssl_context


def _ai_agent_codex_home() -> Path:
    override = os.environ.get("JSAUX_AI_AGENT_CODEX_HOME", "").strip()
    if override:
        return Path(override).expanduser()
    home = Path.home() / ".codex"
    # Decky loader runs the plugin as root (HOME=/root); the deck user's
    # codex credentials live under /home/deck and are the canonical store.
    deck_home = Path("/home/deck/.codex")
    if home != deck_home and deck_home.is_dir():
        return deck_home
    return home


def _ai_agent_local_auth_path() -> Path:
    return _ai_agent_codex_home() / "auth.json"


def _ai_agent_accounts_file() -> Path:
    override = os.environ.get("JSAUX_AI_AGENT_ACCOUNTS_FILE", "").strip()
    if override:
        return Path(override).expanduser()
    return PLUGIN_ROOT / "data" / AI_AGENT_ACCOUNTS_FILENAME


def _ai_agent_accounts_dir() -> Path:
    return PLUGIN_ROOT / "data" / AI_AGENT_ACCOUNTS_DIRNAME


def _ai_agent_sanitize_account_name(name: str) -> str:
    cleaned = re.sub(r"[^\w一-鿿-]", "_", str(name or "").strip())
    return cleaned.strip("_")[:32]


def _ai_agent_library_account_path(name: str) -> Path:
    return _ai_agent_accounts_dir() / f"{_ai_agent_sanitize_account_name(name)}.json"


def _ai_agent_load_library_accounts() -> list:
    try:
        with _ai_agent_accounts_file().open(encoding="utf-8") as f:
            accounts = json.load(f).get("accounts") or []
    except FileNotFoundError:
        return []
    except Exception as exc:
        decky.logger.info(f"AI Agent accounts.json read failed: {exc}")
        return []
    return [a for a in accounts if isinstance(a, dict) and a.get("name")]


def _ai_agent_save_library_accounts(accounts: list) -> None:
    path = _ai_agent_accounts_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump({"accounts": accounts}, f, ensure_ascii=False, indent=2)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def _ai_agent_file_account_id(path: Path) -> str | None:
    try:
        with path.open(encoding="utf-8") as f:
            return ((json.load(f) or {}).get("tokens") or {}).get("account_id")
    except Exception:
        return None


def _ai_agent_collect_specs() -> list:
    """本机账号始终第一；账号库其余账号去重后追加（与本机同一 account_id 的跳过）。"""
    local_path = _ai_agent_local_auth_path()
    specs = [{"name": "本机账号", "auth_file": str(local_path), "active": True}]
    local_id = _ai_agent_file_account_id(local_path) if local_path.exists() else None
    for entry in _ai_agent_load_library_accounts():
        raw = str(entry.get("auth_file", ""))
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = PLUGIN_ROOT / raw
        if not path.exists():
            specs.append({"name": str(entry["name"]), "auth_file": "", "active": False,
                          "error": "account_file_missing"})
            continue
        if local_id and _ai_agent_file_account_id(path) == local_id:
            continue
        specs.append({"name": str(entry["name"]), "auth_file": str(path), "active": False})
    return specs


def _ai_agent_next_account_name() -> str:
    existing = {a["name"] for a in _ai_agent_load_library_accounts()}
    index = 2
    while f"账号 {index}" in existing:
        index += 1
    return "账号 2" if index == 2 else f"账号 {index}"


def _ai_agent_import_account(name: str | None = None) -> dict:
    local_path = _ai_agent_local_auth_path()
    if not local_path.exists():
        return {"ok": False, "error": "ai_agent_no_credentials"}
    account_name = _ai_agent_sanitize_account_name(name) or _ai_agent_next_account_name()
    account_id = _ai_agent_file_account_id(local_path)
    accounts = _ai_agent_load_library_accounts()
    for entry in accounts:
        entry_path = _ai_agent_library_account_path(str(entry["name"]))
        if entry_path.exists() and _ai_agent_file_account_id(entry_path) == account_id:
            return {"ok": False, "error": "ai_agent_account_already_imported"}
    _ai_agent_accounts_dir().mkdir(parents=True, exist_ok=True)
    target = _ai_agent_library_account_path(account_name)
    shutil.copyfile(local_path, target)
    os.chmod(target, 0o600)
    accounts.append({"name": account_name, "auth_file": str(target)})
    _ai_agent_save_library_accounts(accounts)
    return {"ok": True, "name": account_name}


def _ai_agent_enable_account(name: str) -> dict:
    source = _ai_agent_library_account_path(name)
    if not source.exists():
        return {"ok": False, "error": "ai_agent_account_not_found"}
    local_path = _ai_agent_local_auth_path()
    if local_path.exists():
        current_id = _ai_agent_file_account_id(local_path)
        known_ids = {
            _ai_agent_file_account_id(_ai_agent_library_account_path(str(entry["name"])))
            for entry in _ai_agent_load_library_accounts()
        }
        if current_id and current_id not in known_ids:
            # 启用前先把当前本机账号备份进账号库，避免丢失登录态
            backup_name = _ai_agent_next_account_name()
            _ai_agent_accounts_dir().mkdir(parents=True, exist_ok=True)
            backup_path = _ai_agent_library_account_path(backup_name)
            shutil.copyfile(local_path, backup_path)
            os.chmod(backup_path, 0o600)
            accounts = _ai_agent_load_library_accounts()
            accounts.append({"name": backup_name, "auth_file": str(backup_path)})
            _ai_agent_save_library_accounts(accounts)
    else:
        _ai_agent_codex_home().mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, local_path)
    os.chmod(local_path, 0o600)
    return {"ok": True, "enabled": _ai_agent_sanitize_account_name(name)}


def _ai_agent_device_id() -> str:
    path = PLUGIN_ROOT / "data" / "ai_agent_device_id"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            did = path.read_text(encoding="utf-8").strip()
            if did:
                return did
        did = str(uuid.uuid4())
        path.write_text(did, encoding="utf-8")
        return did
    except Exception:
        return str(uuid.uuid4())


def _ai_agent_jwt_client_id(access_token: str) -> str:
    try:
        payload = access_token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        aud = json.loads(base64.urlsafe_b64decode(payload)).get("aud")
        return aud if isinstance(aud, str) else AI_AGENT_DEFAULT_CLIENT_ID
    except Exception:
        return AI_AGENT_DEFAULT_CLIENT_ID


def _ai_agent_load_auth(path: Path | None = None) -> dict:
    auth: dict = {"access_token": None, "refresh_token": None, "account_id": None}
    target = path or _ai_agent_local_auth_path()
    try:
        with target.open(encoding="utf-8") as f:
            tokens = (json.load(f) or {}).get("tokens") or {}
        auth["access_token"] = tokens.get("access_token")
        auth["refresh_token"] = tokens.get("refresh_token")
        auth["account_id"] = tokens.get("account_id")
    except FileNotFoundError:
        pass
    except Exception as exc:
        decky.logger.info(f"AI Agent auth.json read failed: {exc}")
    return auth


def _ai_agent_save_auth(tokens: dict, path: Path | None = None) -> None:
    path = path or _ai_agent_local_auth_path()
    try:
        with path.open(encoding="utf-8") as f:
            auth = json.load(f)
    except Exception:
        auth = {}
    auth["tokens"] = {**(auth.get("tokens") or {}), **tokens}
    fd, tmp = tempfile.mkstemp(dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(auth, f, ensure_ascii=False, indent=2)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def _ai_agent_refresh_access_token(refresh_token: str, client_id: str,
                                   save_path: Path | None = None) -> dict | None:
    body = urllib.parse.urlencode({
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": client_id,
    }).encode()
    req = urllib.request.Request(
        AI_AGENT_TOKEN_URL,
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req, timeout=20, context=_ai_agent_https_context()) as r:
            data = json.loads(r.read().decode())
    except Exception as exc:
        decky.logger.info(f"AI Agent token refresh failed: {exc}")
        return None
    tokens = {
        "access_token": data.get("access_token"),
        "id_token": data.get("id_token"),
        "refresh_token": data.get("refresh_token", refresh_token),
    }
    try:
        _ai_agent_save_auth(tokens, save_path)
    except Exception as exc:
        decky.logger.info(f"AI Agent auth.json write-back failed: {exc}")
    return tokens


def _ai_agent_norm_window(window: dict | None) -> dict | None:
    if not window:
        return None
    return {
        "used_percent": window.get("used_percent"),
        "window_seconds": window.get("limit_window_seconds"),
        "reset_at": window.get("reset_at"),
        "reset_after_seconds": window.get("reset_after_seconds"),
    }


def _ai_agent_fetch_usage(auth: dict, force: bool = False,
                          cache_key: str = "local") -> dict:
    now = time.time()
    cached_entry = _ai_agent_usage_cache.get(cache_key)
    if (
        not force
        and cached_entry is not None
        and now - cached_entry["ts"] < AI_AGENT_USAGE_TTL_SECONDS
    ):
        return cached_entry["account"]

    result = {
        "name": "本机账号", "email": None, "plan_type": None,
        "allowed": None, "limit_reached": None,
        "primary": None, "secondary": None, "extra_limits": [],
        "credits_balance": None, "error": None,
        "fetched_at": int(now),
    }
    if not auth.get("access_token"):
        result["error"] = "ai_agent_no_credentials"
        return result

    data = None
    for attempt in (1, 2):
        req = urllib.request.Request(AI_AGENT_USAGE_URL, headers={
            "Authorization": f"Bearer {auth['access_token']}",
            "chatgpt-account-id": auth.get("account_id") or "",
            "User-Agent": "codex_cli_rs",
            "Accept": "application/json",
        })
        try:
            with urllib.request.urlopen(req, timeout=15, context=_ai_agent_https_context()) as r:
                data = json.loads(r.read().decode())
            break
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403) and attempt == 1 and auth.get("refresh_token"):
                refreshed = _ai_agent_refresh_access_token(
                    auth["refresh_token"],
                    _ai_agent_jwt_client_id(auth["access_token"] or ""),
                    auth.get("_save_path"),
                )
                if refreshed and refreshed.get("access_token"):
                    auth["access_token"] = refreshed["access_token"]
                    auth["refresh_token"] = refreshed["refresh_token"]
                    continue
            result["error"] = f"ai_agent_http_{exc.code}"
            return result
        except Exception as exc:
            result["error"] = f"ai_agent_request_failed: {exc}"
            return result
        # 官方接口偶发只返回主窗口（5 小时窗口缺失），立即重试一次
        rate_limit = data.get("rate_limit") or {}
        if attempt == 1 and rate_limit.get("primary_window") and not rate_limit.get("secondary_window"):
            continue

    rate_limit = data.get("rate_limit") or {}
    result["email"] = data.get("email")
    result["plan_type"] = data.get("plan_type")
    result["allowed"] = rate_limit.get("allowed")
    result["limit_reached"] = rate_limit.get("limit_reached")
    result["primary"] = _ai_agent_norm_window(rate_limit.get("primary_window"))
    result["secondary"] = _ai_agent_norm_window(rate_limit.get("secondary_window"))
    for item in data.get("additional_rate_limits") or []:
        if isinstance(item, dict) and item.get("rate_limit"):
            sub = item["rate_limit"]
            result["extra_limits"].append({
                "name": item.get("limit_name") or "extra",
                "primary": _ai_agent_norm_window(sub.get("primary_window")),
                "secondary": _ai_agent_norm_window(sub.get("secondary_window")),
            })
    credits = data.get("credits") or {}
    if credits.get("has_credits"):
        result["credits_balance"] = credits.get("balance")

    _ai_agent_usage_cache[cache_key] = {"ts": time.time(), "account": result}
    return result


def _ai_agent_lock_held(path: Path) -> bool:
    try:
        fd = os.open(path, os.O_RDWR)
    except Exception:
        return False
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(fd, fcntl.LOCK_UN)
        return False
    except BlockingIOError:
        return True
    except Exception:
        return False
    finally:
        os.close(fd)


def _ai_agent_cli_alive() -> bool:
    try:
        out = subprocess.run(
            ["ps", "-axo", "command="], capture_output=True, text=True, timeout=10
        ).stdout
    except Exception:
        return False
    for line in out.splitlines():
        cmd = line.strip()
        if not cmd or "codex" not in cmd.lower():
            continue
        if "/Applications/ChatGPT.app/" in cmd or "com.openai." in cmd:
            continue
        if os.path.basename(cmd.split()[0]) == "codex":
            return True
    return False


def _ai_agent_load_thread_names() -> dict:
    names: dict = {}
    try:
        with (_ai_agent_codex_home() / "session_index.jsonl").open(encoding="utf-8") as f:
            for line in f:
                try:
                    rec = json.loads(line)
                    names[rec.get("id")] = rec.get("thread_name") or ""
                except Exception:
                    continue
    except FileNotFoundError:
        pass
    except Exception as exc:
        decky.logger.info(f"AI Agent session_index read failed: {exc}")
    return names


def _ai_agent_scan_sessions() -> dict:
    now = time.time()
    cutoff = now - AI_AGENT_SESSION_ACTIVE_MINUTES * 60
    names = _ai_agent_load_thread_names()
    cli = _ai_agent_cli_alive()
    items: dict = {}

    def ensure(tid: str) -> dict:
        it = items.get(tid)
        if it is None:
            it = items[tid] = {
                "thread_id": tid, "name": names.get(tid) or "",
                "last_active_ts": 0.0, "sources": [], "live": False,
            }
        return it

    locks_dir = _ai_agent_codex_home() / "thread-writer-locks"
    try:
        for path in locks_dir.iterdir():
            stem = path.name.removesuffix(".lock")
            if not path.name.endswith(".lock") or not AI_AGENT_UUID_RE.fullmatch(stem):
                continue
            try:
                mtime = path.stat().st_mtime
            except OSError:
                continue
            it = ensure(stem)
            it["last_active_ts"] = max(it["last_active_ts"], mtime)
            if "线程锁" not in it["sources"]:
                it["sources"].append("线程锁")
            if _ai_agent_lock_held(path) or cli:
                it["live"] = True
    except FileNotFoundError:
        pass

    sessions_root = _ai_agent_codex_home() / "sessions"
    if sessions_root.exists():
        for path in sessions_root.rglob("*.jsonl"):
            try:
                mtime = path.stat().st_mtime
            except OSError:
                continue
            if mtime < cutoff:
                continue
            uuids = AI_AGENT_UUID_RE.findall(path.name)
            tid = uuids[0] if uuids else path.name
            it = ensure(tid)
            it["last_active_ts"] = max(it["last_active_ts"], mtime)
            if "会话文件" not in it["sources"]:
                it["sources"].append("会话文件")
            if cli and mtime >= now - 120:
                it["live"] = True

    running, recent = [], []
    for it in items.values():
        it["ago_seconds"] = int(now - it["last_active_ts"]) if it["last_active_ts"] else None
        it["name"] = it["name"] or "(未命名会话)"
        it["status"] = "running" if it["live"] else "recent"
        it["sources"] = sorted(it["sources"])
        (running if it["live"] else recent).append(it)
    running.sort(key=lambda x: -(x["last_active_ts"] or 0))
    recent.sort(key=lambda x: -(x["last_active_ts"] or 0))
    return {
        "running_count": len(running),
        "recent_count": len(recent),
        "items": running + recent,
    }


def _ai_agent_fetch_web_activity(auth: dict) -> list:
    now = time.time()
    if now - _ai_agent_web_cache["ts"] < AI_AGENT_WEB_TTL_SECONDS:
        return _ai_agent_web_cache["items"]
    if not auth.get("access_token"):
        return _ai_agent_web_cache["items"]
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36"
        ),
        "Accept": "application/json",
        "oai-device-id": _ai_agent_device_id(),
        "Authorization": f"Bearer {auth['access_token']}",
        "chatgpt-account-id": auth.get("account_id") or "",
    }
    req = urllib.request.Request(AI_AGENT_CONVERSATIONS_URL, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15, context=_ai_agent_https_context()) as r:
            data = json.loads(r.read().decode())
    except Exception as exc:
        decky.logger.info(f"AI Agent web conversations fetch failed: {exc}")
        return _ai_agent_web_cache["items"]

    items = []
    for conversation in data.get("items") or []:
        raw_time = conversation.get("update_time") or ""
        try:
            ts = time.mktime(time.strptime(raw_time[:19], "%Y-%m-%dT%H:%M:%S"))
        except Exception:
            continue
        if ts < now - AI_AGENT_SESSION_ACTIVE_MINUTES * 60:
            continue
        items.append({
            "thread_id": conversation.get("id") or "",
            "name": conversation.get("title") or "(无标题网页对话)",
            "last_active_ts": ts,
            "ago_seconds": int(now - ts),
            "sources": ["网页对话"],
            "status": "running",
        })
    _ai_agent_web_cache["ts"] = time.time()
    _ai_agent_web_cache["items"] = items
    return items


def _ai_agent_format_token_count(total: int) -> str:
    if total < 1000:
        return str(total)
    if total < 1000**2:
        return f"{total // 1000}K"
    if total < 1000**3:
        return f"{total // 1000**2}M"
    return f"{total // 1000**3}B"


def _ai_agent_last_session_tokens(path: Path) -> int | None:
    """读取 rollout 文件尾部的最近一次 token 累计（不含缓存命中输入）。"""
    try:
        size = path.stat().st_size
        with path.open("rb") as handle:
            if size > 262144:
                handle.seek(-262144, os.SEEK_END)
            tail = handle.read().decode("utf-8", "ignore")
    except OSError:
        return None
    marker = '"total_token_usage":'
    index = tail.rfind(marker)
    if index < 0:
        return None
    fragment = tail[index + len(marker):]
    end = fragment.find("}")
    if end < 0:
        return None
    try:
        usage = json.loads(fragment[:end + 1])
        return int(usage.get("input_tokens") or 0) + int(usage.get("output_tokens") or 0)
    except (json.JSONDecodeError, TypeError, ValueError):
        return None


def _ai_agent_token_totals(force: bool = False) -> dict:
    """按 5 小时 / 7 天滑动窗口聚合本机 codex 会话 Token 用量。"""
    now = time.time()
    cached = _ai_agent_tokens_cache
    if not force and cached["totals"] is not None and now - cached["ts"] < AI_AGENT_TOKENS_TTL_SECONDS:
        return cached["totals"]
    sessions_root = _ai_agent_codex_home() / "sessions"
    fallback = "0" if sessions_root.exists() else None
    totals = {"tokens_5h": fallback, "tokens_7d": fallback}
    sums = {"tokens_5h": 0, "tokens_7d": 0}
    seen = {"tokens_5h": False, "tokens_7d": False}
    try:
        candidates = list(sessions_root.rglob("*.jsonl")) if sessions_root.exists() else []
    except OSError:
        candidates = []
    for path in candidates:
        try:
            age = now - path.stat().st_mtime
        except OSError:
            continue
        if age > 7 * 86400:
            continue
        total = _ai_agent_last_session_tokens(path)
        if total is None:
            continue
        if age <= 5 * 3600:
            sums["tokens_5h"] += total
            seen["tokens_5h"] = True
        sums["tokens_7d"] += total
        seen["tokens_7d"] = True
    for key, value in sums.items():
        if seen[key]:
            totals[key] = _ai_agent_format_token_count(value)
    cached["ts"] = now
    cached["totals"] = totals
    return totals


def _ai_agent_screen_payload(force: bool = False) -> dict:
    """点阵屏 AI Agent 模块的数据载荷：7H/7D 剩余额度、对话数与 Token 总量。

    force=True 时绕过额度缓存实时拉取（切入模块那次），后台轮询走默认缓存。
    """
    status = _ai_agent_status(force=force)
    accounts = status.get("accounts") or []
    active = next((a for a in accounts if a.get("active") and not a.get("error")), None)
    if active is None:
        active = next((a for a in accounts if not a.get("error")), None)
    def _pick_window(prefer_main, extra_key, hours_only):
        """5小时/7天窗口：官方主结构缺失时（接口偶发返回 null）回落到附加限额。"""
        main_key = "secondary" if prefer_main else "primary"
        main_window = (active or {}).get(main_key) or {}
        if main_window.get("used_percent") is not None:
            return main_window
        for extra in (active or {}).get("extra_limits") or []:
            window = extra.get(extra_key) or {}
            if window.get("used_percent") is None:
                continue
            if hours_only:
                seconds = window.get("window_seconds") or 0
                if not seconds or seconds > 48 * 3600:
                    continue
            return window
        return None

    def _remaining(window):
        if window is None or window.get("used_percent") is None:
            return -1
        return max(0, min(100, 100 - int(window["used_percent"])))

    short_window = _pick_window(True, "primary", True)
    long_window = _pick_window(False, "secondary", False)
    tokens = status.get("tokens") or {}
    conversations = len((status.get("sessions") or {}).get("items") or [])
    return {
        "conversations": min(conversations, 999),
        "primaryPercent": _remaining(short_window),
        "secondaryPercent": _remaining(long_window),
        "tokensPrimary": tokens.get("tokens_5h") or "--",
        "tokensSecondary": tokens.get("tokens_7d") or "--",
    }


def _ai_agent_status(force: bool = False) -> dict:
    accounts = []
    active_auth = {"access_token": None, "refresh_token": None, "account_id": None}
    for spec in _ai_agent_collect_specs():
        if spec.get("error"):
            accounts.append({
                "name": spec["name"], "active": spec.get("active", False),
                "error": spec["error"],
            })
            continue
        auth_path = Path(spec["auth_file"])
        auth = _ai_agent_load_auth(auth_path)
        auth["_save_path"] = auth_path
        usage = _ai_agent_fetch_usage(auth, force, cache_key=f"path:{auth_path}")
        usage["name"] = spec["name"]
        usage["active"] = spec.get("active", False)
        usage["library"] = not spec.get("active", False)
        accounts.append(usage)
        if spec.get("active"):
            active_auth = auth

    local_auth_path = _ai_agent_local_auth_path()
    authenticated = bool(_ai_agent_load_auth(local_auth_path).get("access_token")) if local_auth_path.exists() else False
    local = _ai_agent_scan_sessions()
    merged = {it["thread_id"]: dict(it) for it in local["items"]}
    for it in _ai_agent_fetch_web_activity(active_auth):
        current = merged.get(it["thread_id"])
        if current is None:
            merged[it["thread_id"]] = it
        elif it["last_active_ts"] > current.get("last_active_ts") or 0:
            current["last_active_ts"] = it["last_active_ts"]
            current["ago_seconds"] = it["ago_seconds"]
            current["sources"] = sorted(set(current["sources"]) | set(it["sources"]))
    items = sorted(merged.values(), key=lambda x: -(x.get("last_active_ts") or 0))
    return {
        "accounts": accounts,
        "authenticated": authenticated,
        "sessions": {
            "running_count": sum(1 for it in items if it.get("status") == "running"),
            "recent_count": local["recent_count"],
            "web_count": sum(1 for it in items if "网页对话" in it["sources"]),
            "items": items,
        },
        "tokens": _ai_agent_token_totals(),
        "active_minutes": AI_AGENT_SESSION_ACTIVE_MINUTES,
        "generated_at": int(time.time()),
    }


# ---------------------------------------------------------------- 账号登录

def _ai_agent_codex_bin() -> str:
    return os.environ.get("JSAUX_AI_AGENT_CODEX_BIN", "codex")


def _ai_agent_login_start() -> dict:
    if _ai_agent_login["proc"] is not None and _ai_agent_login["proc"].poll() is None:
        return {"ok": True, "started": False, "running": True}
    codex_bin = _ai_agent_codex_bin()
    if shutil.which(codex_bin) is None:
        return {"ok": False, "error": "ai_agent_codex_cli_not_found"}
    local_path = _ai_agent_local_auth_path()
    try:
        auth_mtime = local_path.stat().st_mtime if local_path.exists() else 0.0
    except OSError:
        auth_mtime = 0.0
    _ai_agent_login["proc"] = subprocess.Popen(
        [codex_bin, "login"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        cwd=str(PLUGIN_ROOT),
    )
    _ai_agent_login["output"] = []
    _ai_agent_login["auth_mtime"] = auth_mtime

    def _reader(proc, sink):
        for line in proc.stdout:
            sink.append(line.rstrip())

    threading.Thread(
        target=_reader,
        args=(_ai_agent_login["proc"], _ai_agent_login["output"]),
        daemon=True,
    ).start()
    return {"ok": True, "started": True, "running": True}


def _ai_agent_login_status() -> dict:
    proc = _ai_agent_login["proc"]
    if proc is None:
        return {"ok": True, "running": False, "finished": False, "started": False,
                "url": None, "changed": False}
    output = "\n".join(_ai_agent_login["output"])
    url_match = AI_AGENT_LOGIN_URL_RE.search(output)
    local_path = _ai_agent_local_auth_path()
    try:
        auth_mtime = local_path.stat().st_mtime if local_path.exists() else 0.0
    except OSError:
        auth_mtime = 0.0
    running = proc.poll() is None
    return {
        "ok": True,
        "started": True,
        "running": running,
        "finished": not running,
        "url": url_match.group(0) if url_match else None,
        "changed": auth_mtime > 0 and auth_mtime != _ai_agent_login["auth_mtime"],
        "exit_code": proc.returncode if not running else None,
    }


def _ai_agent_logout() -> dict:
    """退出登录：备份并移除本机 auth.json，再尽力调用 codex logout 吊销凭证。"""
    local_path = _ai_agent_local_auth_path()
    removed = False
    if local_path.exists():
        try:
            shutil.copy2(local_path, local_path.with_name("auth.json.bak"))
        except OSError:
            pass
        try:
            local_path.unlink()
            removed = True
        except OSError as exc:
            return {"ok": False, "error": f"ai_agent_logout_failed: {exc}"}
    codex_bin = shutil.which(_ai_agent_codex_bin())
    if codex_bin:
        try:
            subprocess.run([codex_bin, "logout"], capture_output=True, timeout=20)
        except Exception:
            pass
    _ai_agent_usage_cache.clear()
    _ai_agent_web_cache.update({"ts": 0.0, "items": []})
    return {"ok": True, "removed": removed}


class Plugin:
    def __init__(self) -> None:
        daemon_url = os.environ.get("JSAUX_DAEMON_URL", "http://127.0.0.1:39052")
        self.client = DaemonHttpClient(daemon_url)
        self._serial_lock = threading.Lock()
        self._dashboard_generation = 0
        self._clock_generation = 0
        self._playtime_generation = 0
        self._playtime_current_app_id = ""
        self._playtime_session_started_at = time.time() - (3 * 3600 + 56 * 60)
        self._playtime_context_lock = threading.Lock()
        self._playtime_session_key: tuple[str, int] | None = None
        self._playtime_baseline_minutes = 0
        self._countdown_generation = 0
        self._countdown_total_seconds = 30 * 60
        self._countdown_started_at = time.time() - (10 * 60 + 1)
        self._chronograph_generation = 0
        self._chronograph_total_seconds = CHRONOGRAPH_MAX_SECONDS
        self._chronograph_started_at = time.time()
        self._chronograph_loop_active = False
        self._chronograph_watchdog_generation = 0
        self._ai_agent_generation = 0

    async def get_status(self):
        return await self.client.aget("/v1/device")

    async def get_profiles(self):
        return await self.client.aget("/v1/profiles")

    async def get_modules(self):
        return await self.client.aget("/v1/modules")

    async def get_display_settings(self):
        return await self.client.aget("/v1/settings/display")

    async def get_custom_assets(self):
        return await self.client.aget("/v1/custom/assets")

    async def get_countdown(self):
        return await self.client.aget("/v1/timer/countdown")

    async def get_chronograph(self):
        return await self.client.aget("/v1/timer/chronograph")

    async def get_ai_agent_status(self, force: bool = False):
        return await asyncio.to_thread(_ai_agent_status, bool(force))

    async def ai_agent_import_account(self, name: str = ""):
        return await asyncio.to_thread(_ai_agent_import_account, str(name or ""))

    async def ai_agent_enable_account(self, name: str = ""):
        return await asyncio.to_thread(_ai_agent_enable_account, str(name or ""))

    async def ai_agent_login_start(self):
        return await asyncio.to_thread(_ai_agent_login_start)

    async def ai_agent_login_status(self):
        return await asyncio.to_thread(_ai_agent_login_status)

    async def ai_agent_logout(self):
        return await asyncio.to_thread(_ai_agent_logout)

    async def set_brightness(self, brightness: int):
        return await self.client.apost("/v1/device/brightness", {"brightness": brightness})

    async def set_power(self, enabled: bool):
        return await self.client.apost("/v1/device/power", {"enabled": enabled})

    async def send_test_pattern(self, pattern: str):
        return await self.client.apost("/v1/device/test-pattern", {"pattern": pattern})

    async def apply_profile(self, app_id: str):
        return await self.client.apost("/v1/display/profile/apply", {"appId": app_id})

    async def update_display_settings(self, payload: dict):
        result = await self.client.apost("/v1/settings/display", payload)
        if self._display_update_requests_custom(payload):
            settings = result.get("displaySettings") if isinstance(result, dict) else None
            if not isinstance(settings, dict):
                try:
                    settings = await self.get_display_settings()
                    if isinstance(settings.get("displaySettings"), dict):
                        settings = settings["displaySettings"]
                except Exception as exc:
                    decky.logger.info(f"Chronograph custom activation check skipped: {exc}")
                    settings = None
            if isinstance(settings, dict) and self._settings_have_active_chronograph(settings):
                decky.logger.info("Chronograph monitor restarted after custom display activation")
                return await self.send_chronograph_monitor(CHRONOGRAPH_MAX_SECONDS)
        return result

    @staticmethod
    def _normalize_display_refresh_rate(refresh_rate: float) -> int:
        try:
            normalized = int(float(refresh_rate) + 0.5)
        except (TypeError, ValueError, OverflowError):
            return 0
        return normalized if 1 <= normalized <= 999 else 0

    async def update_display_refresh_rate(self, refresh_rate: float = 0):
        return await self.client.apost(
            "/v1/runtime/display-refresh-rate",
            {"refreshRate": self._normalize_display_refresh_rate(refresh_rate)},
        )

    async def select_custom_asset(self, asset: str):
        if self._is_chronograph_asset(asset):
            return await self.send_chronograph_monitor(CHRONOGRAPH_MAX_SECONDS)
        return await self.client.apost("/v1/custom/assets/select", {"asset": asset})

    async def upload_custom_asset(self, filename: str, content_base64: str):
        return await self.client.apost(
            "/v1/custom/assets/upload",
            {"filename": filename, "content_base64": content_base64},
        )

    async def upload_custom_asset_from_path(self, source_path: str):
        source = Path(source_path).expanduser()
        try:
            source = source.resolve(strict=True)
        except (OSError, RuntimeError):
            return {"ok": False, "error": "custom_asset_file_not_found"}
        if not source.is_file() or source.suffix.lower() not in CUSTOM_ASSET_EXTENSIONS:
            return {"ok": False, "error": "custom_asset_file_not_found"}
        try:
            content_base64 = base64.b64encode(source.read_bytes()).decode("ascii")
        except OSError:
            return {"ok": False, "error": "custom_asset_file_read_failed"}
        return await self.upload_custom_asset(source.name, content_base64)

    async def list_custom_asset_files(self, folder_path: str):
        """List supported images in a folder selected by Decky's native picker."""
        folder = Path(folder_path).expanduser()
        try:
            folder = folder.resolve(strict=True)
        except (OSError, RuntimeError):
            return {"ok": False, "error": "custom_asset_folder_not_found"}
        if not folder.is_dir():
            return {"ok": False, "error": "custom_asset_folder_not_found"}

        try:
            candidates = sorted(
                (
                    item
                    for item in folder.iterdir()
                    if item.is_file() and item.suffix.lower() in CUSTOM_ASSET_EXTENSIONS
                ),
                key=lambda item: item.name.casefold(),
            )
        except OSError:
            return {"ok": False, "error": "custom_asset_folder_read_failed"}

        mime_types = {
            ".png": "image/png",
            ".gif": "image/gif",
            ".svg": "image/svg+xml",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".bmp": "image/bmp",
        }
        files = []
        for item in candidates[:CUSTOM_ASSET_DIRECTORY_LIMIT]:
            preview = ""
            try:
                data = item.read_bytes()
                if 0 < len(data) <= CUSTOM_ASSET_PREVIEW_LIMIT_BYTES:
                    preview = (
                        f"data:{mime_types[item.suffix.lower()]};base64,"
                        f"{base64.b64encode(data).decode('ascii')}"
                    )
            except OSError:
                # Keep the filename visible. Upload reports a precise read error
                # if the file disappears before the user confirms it.
                pass
            files.append({"name": item.name, "path": str(item), "preview": preview})

        return {
            "ok": True,
            "folder": str(folder),
            "files": files,
            "truncated": len(candidates) > CUSTOM_ASSET_DIRECTORY_LIMIT,
        }

    async def delete_custom_asset(self, asset: str):
        return await self.client.apost("/v1/custom/assets/delete", {"asset": asset})

    async def sync_display(self, module_id: str = ""):
        normalized_module_id = module_id.lower()
        if normalized_module_id in {"chronograph", "countup"}:
            return await self.send_chronograph_monitor(CHRONOGRAPH_MAX_SECONDS)
        if normalized_module_id == "custom":
            settings = await self.get_display_settings()
            if isinstance(settings.get("displaySettings"), dict):
                settings = settings["displaySettings"]
            custom = settings.get("custom", {})
            if isinstance(custom, dict):
                current_asset = custom.get("current_asset") or custom.get("currentAsset")
                if self._is_chronograph_asset(str(current_asset)):
                    return await self.send_chronograph_monitor(CHRONOGRAPH_MAX_SECONDS)
        if normalized_module_id:
            self._stop_legacy_monitor_loops()
        payload = {"moduleId": module_id} if module_id else {}
        return await self.client.apost("/v1/display/sync", payload)

    async def sync_context_now(self, sync_display: bool = True):
        context = self._daemon_steam_context()
        payload = dict(context)
        if not sync_display:
            payload["syncDisplay"] = False
        await self.client.apost("/v1/runtime/steam-context", payload)
        return context

    def _daemon_steam_context(self):
        context = dict(self._scan_context())
        context["source"] = "decky"
        app_id = str(context.get("appId") or "")
        try:
            session_started_at = max(0, int(round(float(context.get("sessionStartedAt") or 0))))
        except (TypeError, ValueError):
            session_started_at = 0
        context["sessionStartedAt"] = session_started_at

        if not app_id or not bool(context.get("running")):
            return context

        try:
            reported_total = max(0, int(context.get("totalPlaytimeMinutes") or 0))
        except (TypeError, ValueError):
            reported_total = 0
        session_key = (app_id, session_started_at)
        with self._playtime_context_lock:
            same_session = (
                self._playtime_session_key is not None
                and self._playtime_session_key[0] == app_id
                and abs(self._playtime_session_key[1] - session_started_at) <= 2
            )
            if not same_session:
                self._playtime_session_key = session_key
                self._playtime_baseline_minutes = reported_total
            else:
                context["sessionStartedAt"] = self._playtime_session_key[1]
            context["totalPlaytimeMinutes"] = self._playtime_baseline_minutes
        return context

    def _sync_playtime_context_now(self):
        context = self._daemon_steam_context()
        payload = dict(context)
        payload["syncDisplay"] = False
        return self.client.post("/v1/runtime/steam-context", payload)

    async def refresh_and_sync(self):
        context = await self.sync_context_now()
        await self.sync_display()
        return {"ok": True, "context": context}

    async def health(self):
        return {"ok": True}

    async def write_serial_hex(self, hex_string: str, port: str = "", baudrate: int = 1000000):
        normalized = "".join(hex_string.strip().split()).upper()
        frame = self._parse_matrix_frame(normalized)
        if frame and frame["data_type"] == 0x01:
            command = frame["command"]
            data = frame["data"]
            if command == 0x01 and len(data) >= 1:
                result = await self.set_power(data[0] != 0)
                return self._daemon_serial_result(result, "power", normalized)
            if command == 0x02 and len(data) >= 1:
                brightness = max(0, min(100, int(data[0])))
                result = await self.set_brightness(brightness)
                return self._daemon_serial_result(result, "brightness", normalized)
            if command == 0x21 and len(data) >= 1:
                return await self._activate_mode_hex(data[0])
        if normalized == "445901040008000004A46CEAA0642CF6":
            return await self._activate_builtin_custom_asset("rainbow_scroll")
        if os.environ.get("JSAUX_ALLOW_RAW_SERIAL", "").lower() in ("1", "true", "yes", "on"):
            return self._write_serial_hex(hex_string, port, baudrate)
        return {
            "ok": True,
            "mode": "daemon-ignored",
            "port": "daemon",
            "written": 0,
            "txHex": self._format_hex(normalized),
            "rxHex": "",
            "message": "Raw serial command ignored because the daemon owns the USB serial port.",
        }

    async def send_dashboard_monitor(self, refresh_rate: float = 0, port: str = "", baudrate: int = 1000000):
        del refresh_rate
        return await self._activate_daemon_module(
            "dashboard",
            display_refresh_rate=0,
        )

    async def send_hardware_monitor(self, refresh_rate: float = 0, port: str = "", baudrate: int = 1000000):
        del refresh_rate
        return await self._activate_daemon_module(
            "system_performance",
            display_refresh_rate=0,
        )

    async def send_clock_monitor(self, port: str = "", baudrate: int = 1000000):
        return await self._activate_daemon_module("productivity")

    async def send_weather_forecast(self, port: str = "", baudrate: int = 1000000):
        return await self._activate_daemon_module("weather")

    async def send_playtime_monitor(self, port: str = "", baudrate: int = 1000000):
        result = await self._activate_daemon_module("playtime", sync_context=True)
        if result.get("ok", True):
            self._start_playtime_monitor_loop(port, baudrate)
        return result

    async def send_countdown_monitor(self, minutes: int = 30, seconds: int = 0, port: str = "", baudrate: int = 1000000):
        self._stop_legacy_monitor_loops()
        total_seconds = int(seconds) if int(seconds or 0) > 0 else int(minutes) * 60
        self._countdown_total_seconds = max(1, min((99 * 3600) + (59 * 60) + 59, total_seconds))
        self._countdown_started_at = time.time()
        result = await self.client.apost(
            "/v1/timer/countdown",
            {"totalSeconds": self._countdown_total_seconds},
        )
        return {"mode": "daemon", "moduleId": "countdown", **result}

    async def send_chronograph_monitor(self, seconds: int = CHRONOGRAPH_MAX_SECONDS, port: str = "", baudrate: int = 1000000):
        self._stop_legacy_monitor_loops()
        self._chronograph_total_seconds = max(1, min(CHRONOGRAPH_MAX_SECONDS, int(seconds)))
        self._chronograph_started_at = time.time()
        decky.logger.info("Chronograph monitor start requested")
        result = await self.client.apost(
            "/v1/timer/chronograph",
            {"totalSeconds": self._chronograph_total_seconds},
        )
        return {"mode": "daemon", "moduleId": "chronograph", **result}

    async def send_ai_agent_monitor(self, port: str = "", baudrate: int = 1000000):
        del port, baudrate
        # Activate first so the screen switches instantly; usage data lands
        # 1-2s later via the push below.
        activation = await self._activate_daemon_module("ai_agent")
        if not activation.get("ok", True):
            return activation
        try:
            # 切入模块时强制实时取一次额度；后续轮询循环才走缓存。
            payload = await asyncio.to_thread(_ai_agent_screen_payload, True)
        except Exception as exc:
            decky.logger.info(f"AI Agent payload build failed: {exc}")
            payload = {
                "conversations": 0,
                "primaryPercent": -1,
                "secondaryPercent": -1,
                "tokensPrimary": "--",
                "tokensSecondary": "--",
            }
        pushed = await self.client.apost("/v1/aiagent", payload)
        self._start_ai_agent_monitor_loop()
        return {"ok": True, "mode": "daemon", "moduleId": "ai_agent", "screen": payload, **pushed}

    def _stop_legacy_monitor_loops(self):
        self._dashboard_generation += 1
        self._clock_generation += 1
        self._playtime_generation += 1
        self._countdown_generation += 1
        self._chronograph_generation += 1
        self._chronograph_loop_active = False
        self._ai_agent_generation += 1

    async def _activate_daemon_module(
        self,
        module_id: str,
        sync_context: bool = False,
        display_refresh_rate: int | None = None,
    ):
        self._stop_legacy_monitor_loops()
        if module_id == "dashboard" or sync_context:
            await self.sync_context_now(sync_display=False)
        payload = {
            "activeModuleId": module_id,
            "autoSyncEnabled": True,
            "timeline": {"enabled": False},
        }
        if display_refresh_rate is not None:
            payload["displayRefreshRate"] = display_refresh_rate
        settings = await self.client.apost(
            "/v1/settings/display",
            payload,
        )
        return {"ok": settings.get("ok", True), "mode": "daemon", "moduleId": module_id, "settings": settings}

    async def _activate_mode_hex(self, mode_hex: int):
        mode_map = {
            0x01: "dashboard",
            0x02: "system_performance",
            0x03: "weather",
            0x04: "productivity",
        }
        if mode_hex in mode_map:
            return await self._activate_daemon_module(mode_map[mode_hex])
        if mode_hex == 0x05:
            return await self.send_playtime_monitor()
        if mode_hex == 0x06:
            return await self.send_countdown_monitor()
        if mode_hex == 0x07:
            return await self.send_chronograph_monitor(CHRONOGRAPH_MAX_SECONDS)
        if mode_hex == 0x08:
            return await self._activate_builtin_custom_asset("rainbow_scroll")
        if mode_hex == 0x09:
            return await self.send_ai_agent_monitor()
        return {
            "ok": True,
            "mode": "daemon-ignored",
            "port": "daemon",
            "written": 0,
            "message": f"Unsupported display mode 0x{mode_hex:02X}; raw serial is disabled while daemon owns USB.",
        }

    def _parse_matrix_frame(self, normalized: str):
        if len(normalized) % 2 != 0:
            return None
        try:
            payload = bytes.fromhex(normalized)
        except ValueError:
            return None
        if len(payload) < 8 or payload[0] != 0x44 or payload[1] != 0x59:
            return None
        data_len = (payload[4] << 8) | payload[5]
        data_end = 6 + data_len
        if len(payload) < data_end:
            return None
        return {
            "data_type": payload[2],
            "command": payload[3],
            "data": payload[6:data_end],
            "crc": payload[data_end:],
        }

    def _format_hex(self, normalized: str):
        return " ".join(normalized[index:index + 2] for index in range(0, len(normalized), 2))

    def _daemon_serial_result(self, result: dict, action: str, normalized: str):
        return {
            "ok": result.get("ok", True),
            "mode": "daemon",
            "action": action,
            "port": "daemon",
            "written": 0,
            "txHex": self._format_hex(normalized),
            "rxHex": "",
            "daemon": result,
        }

    async def _activate_custom_gif(self, asset_name: str, gif_data: bytes):
        encoded = base64.b64encode(gif_data).decode("ascii")
        upload = await self.client.apost(
            "/v1/custom/assets/upload",
            {"filename": asset_name, "content_base64": encoded},
        )
        settings = await self.client.apost(
            "/v1/settings/display",
            {
                "activeModuleId": "custom",
                "autoSyncEnabled": True,
                "timeline": {"enabled": False},
                "custom": {"active": True, "currentAsset": asset_name},
            },
        )
        select = await self.client.apost("/v1/custom/assets/select", {"asset": asset_name})
        sync = await self.client.apost("/v1/display/sync", {"moduleId": "custom"})
        return {
            "ok": sync.get("ok", True),
            "mode": "daemon-custom",
            "moduleId": "custom",
            "asset": asset_name,
            "upload": upload,
            "settings": settings,
            "select": select,
            "sync": sync,
        }

    async def _activate_builtin_custom_asset(self, asset_name: str):
        self._stop_legacy_monitor_loops()
        select = await self.client.apost("/v1/custom/assets/select", {"asset": asset_name})
        settings = await self.client.apost(
            "/v1/settings/display",
            {
                "activeModuleId": "custom",
                "autoSyncEnabled": True,
                "timeline": {"enabled": False},
                "custom": {"active": True, "currentAsset": asset_name},
            },
        )
        sync = await self.client.apost("/v1/display/sync", {"moduleId": "custom"})
        return {
            "ok": sync.get("ok", True),
            "mode": "daemon-custom",
            "moduleId": "custom",
            "asset": asset_name,
            "select": select,
            "settings": settings,
            "sync": sync,
        }

    def _activate_custom_gif_sync(self, asset_name: str, gif_data: bytes):
        encoded = base64.b64encode(gif_data).decode("ascii")
        upload = self.client.post(
            "/v1/custom/assets/upload",
            {"filename": asset_name, "content_base64": encoded},
        )
        settings = self.client.post(
            "/v1/settings/display",
            {
                "activeModuleId": "custom",
                "autoSyncEnabled": True,
                "timeline": {"enabled": False},
                "custom": {"active": True, "currentAsset": asset_name},
            },
        )
        select = self.client.post("/v1/custom/assets/select", {"asset": asset_name})
        sync = self.client.post("/v1/display/sync", {"moduleId": "custom"})
        return {
            "ok": sync.get("ok", True),
            "mode": "daemon-custom",
            "moduleId": "custom",
            "asset": asset_name,
            "upload": upload,
            "settings": settings,
            "select": select,
            "sync": sync,
        }

    def _write_serial_hex(self, hex_string: str, port: str = "", baudrate: int = 1000000):
        try:
            import serial
        except ImportError as exc:
            raise RuntimeError("pyserial is not available on this Deck") from exc

        normalized = "".join(hex_string.strip().split())
        if len(normalized) % 2 != 0:
            raise RuntimeError("HEX command has an odd number of characters")

        try:
            payload = bytes.fromhex(normalized)
        except ValueError as exc:
            raise RuntimeError(f"Invalid HEX command: {hex_string}") from exc

        target_port = port or os.environ.get("JSAUX_MATRIX_SERIAL_PORT") or self._detect_serial_port()
        if not target_port:
            raise RuntimeError("No serial device detected")

        try:
            with serial.Serial(
                port=target_port,
                baudrate=int(baudrate),
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.25,
                write_timeout=1,
            ) as serial_port:
                serial_port.reset_input_buffer()
                serial_port.reset_output_buffer()
                written = serial_port.write(payload)
                serial_port.flush()
                reply = serial_port.read(64)
        except Exception as exc:
            raise RuntimeError(f"Serial write failed on {target_port}: {exc}") from exc

        return {
            "ok": written == len(payload),
            "port": target_port,
            "baudrate": int(baudrate),
            "written": written,
            "txHex": payload.hex(" ").upper(),
            "rxHex": reply.hex(" ").upper(),
        }

    def _detect_serial_port(self):
        for candidate in sorted(glob("/dev/ttyUSB*")):
            return candidate
        for candidate in sorted(glob("/dev/ttyACM*")):
            return candidate
        return ""

    def _upload_gif(self, gif_data: bytes, port: str = "", baudrate: int = 1000000):
        try:
            import serial
        except ImportError as exc:
            raise RuntimeError("pyserial is not available on this Deck") from exc

        target_port = port or os.environ.get("JSAUX_MATRIX_SERIAL_PORT") or self._detect_serial_port()
        if not target_port:
            raise RuntimeError("No serial device detected")

        frames = self._encode_gif_upload(gif_data)
        try:
            with self._serial_lock:
                with serial.Serial(
                    port=target_port,
                    baudrate=int(baudrate),
                    bytesize=serial.EIGHTBITS,
                    parity=serial.PARITY_NONE,
                    stopbits=serial.STOPBITS_ONE,
                    timeout=0.25,
                    write_timeout=1,
                ) as serial_port:
                    serial_port.reset_input_buffer()
                    serial_port.reset_output_buffer()
                    written = 0
                    for frame in frames:
                        written += serial_port.write(frame)
                        serial_port.flush()
                        time.sleep(0.01)
                    try:
                        reply = serial_port.read(64)
                    except Exception as exc:
                        decky.logger.info(f"Dashboard upload ACK read skipped: {exc}")
                        reply = b""
        except Exception as exc:
            raise RuntimeError(f"Dashboard upload failed on {target_port}: {exc}") from exc

        return {
            "ok": True,
            "port": target_port,
            "baudrate": int(baudrate),
            "written": written,
            "txHex": f"{len(frames)} frames / {len(gif_data)} GIF bytes",
            "rxHex": reply.hex(" ").upper(),
        }

    def _start_dashboard_monitor_loop(self, port: str = "", baudrate: int = 1000000):
        self._dashboard_generation += 1
        generation = self._dashboard_generation

        def run():
            for _ in range(180):
                time.sleep(1.0)
                if generation != self._dashboard_generation:
                    return
                try:
                    self._upload_gif(self._build_dashboard_gif(), port, baudrate)
                except Exception as exc:
                    decky.logger.info(f"Dashboard monitor refresh stopped: {exc}")
                    return

        thread = threading.Thread(target=run, name="jsaux-dashboard-monitor", daemon=True)
        thread.start()

    def _start_clock_monitor_loop(self, port: str = "", baudrate: int = 1000000):
        self._clock_generation += 1
        generation = self._clock_generation

        def run():
            for _ in range(600):
                time.sleep(max(0.2, 1.02 - (time.time() % 1.0)))
                if generation != self._clock_generation:
                    return
                try:
                    self._upload_gif(self._build_clock_monitor_gif(), port, baudrate)
                except Exception as exc:
                    decky.logger.info(f"Clock monitor refresh stopped: {exc}")
                    return

        thread = threading.Thread(target=run, name="jsaux-clock-monitor", daemon=True)
        thread.start()

    def _start_playtime_monitor_loop(self, port: str = "", baudrate: int = 1000000):
        del port, baudrate
        self._playtime_generation += 1
        generation = self._playtime_generation

        def run():
            while generation == self._playtime_generation:
                time.sleep(max(1.0, PLAYTIME_REFRESH_SECONDS - (time.time() % PLAYTIME_REFRESH_SECONDS)))
                if generation != self._playtime_generation:
                    return
                try:
                    self._sync_playtime_context_now()
                except Exception as exc:
                    decky.logger.info(f"Playtime context refresh skipped: {exc}")

        thread = threading.Thread(target=run, name="jsaux-playtime-monitor", daemon=True)
        thread.start()

    def _start_ai_agent_monitor_loop(self):
        self._ai_agent_generation += 1
        generation = self._ai_agent_generation

        def run():
            while generation == self._ai_agent_generation:
                time.sleep(random.uniform(AI_AGENT_SCREEN_REFRESH_MIN_SECONDS, AI_AGENT_SCREEN_REFRESH_MAX_SECONDS))
                if generation != self._ai_agent_generation:
                    return
                try:
                    payload = _ai_agent_screen_payload()
                    self.client.post("/v1/aiagent", payload)
                except Exception as exc:
                    decky.logger.info(f"AI Agent screen refresh skipped: {exc}")

        thread = threading.Thread(target=run, name="jsaux-ai-agent-monitor", daemon=True)
        thread.start()

    def _start_countdown_monitor_loop(self, port: str = "", baudrate: int = 1000000):
        self._countdown_generation += 1
        generation = self._countdown_generation

        def run():
            for _ in range(self._countdown_total_seconds + 2):
                time.sleep(max(0.2, 1.02 - (time.time() % 1.0)))
                if generation != self._countdown_generation:
                    return
                if not self._current_custom_asset_is("plugin-countdown.gif"):
                    decky.logger.info("Countdown monitor loop stopped by selected UI change")
                    return
                try:
                    self._activate_custom_gif_sync("plugin-countdown.gif", self._build_countdown_monitor_gif())
                except Exception as exc:
                    decky.logger.info(f"Countdown monitor refresh stopped: {exc}")
                    return

        thread = threading.Thread(target=run, name="jsaux-countdown-monitor", daemon=True)
        thread.start()

    def _start_chronograph_monitor_loop(self, port: str = "", baudrate: int = 1000000):
        self._chronograph_generation += 1
        generation = self._chronograph_generation
        self._chronograph_loop_active = True

        def run():
            try:
                next_refresh = time.time()
                for _ in range(self._chronograph_total_seconds + 2):
                    if generation != self._chronograph_generation:
                        decky.logger.info("Chronograph monitor loop stopped by mode change")
                        return
                    if not self._current_custom_asset_is_chronograph():
                        decky.logger.info("Chronograph monitor loop stopped by selected UI change")
                        return
                    try:
                        elapsed = self._chronograph_elapsed_seconds()
                        asset_name = self._chronograph_asset_name(elapsed)
                        self._activate_custom_gif_sync(asset_name, self._build_chronograph_monitor_asset())
                        if elapsed % 60 in {29, 30, 31, 32, 33}:
                            decky.logger.info(f"Chronograph monitor refreshed elapsed={elapsed} asset={asset_name}")
                    except Exception as exc:
                        decky.logger.info(f"Chronograph monitor refresh skipped: {exc}")
                    next_refresh += 1.0
                    time.sleep(max(0.2, next_refresh - time.time()))
            finally:
                if generation == self._chronograph_generation:
                    self._chronograph_loop_active = False

        thread = threading.Thread(target=run, name="jsaux-chronograph-monitor", daemon=True)
        thread.start()

    def _ensure_chronograph_monitor_running_for_active_display(self, port: str = "", baudrate: int = 1000000) -> bool:
        if self._chronograph_loop_active:
            return False

        settings = self.client.get("/v1/settings/display")
        if isinstance(settings.get("displaySettings"), dict):
            settings = settings["displaySettings"]
        if not self._settings_have_active_chronograph(settings):
            return False

        self._chronograph_total_seconds = CHRONOGRAPH_MAX_SECONDS
        self._chronograph_started_at = time.time()
        asset_name = self._chronograph_asset_name(0)
        result = self._activate_custom_gif_sync(asset_name, self._build_chronograph_monitor_asset())
        if not result.get("ok", True):
            decky.logger.info(f"Chronograph watchdog restart failed: {result}")
            return False

        self._start_chronograph_monitor_loop(port, baudrate)
        decky.logger.info("Chronograph watchdog restarted active custom display")
        return True

    def _start_chronograph_activation_watchdog(self):
        self._chronograph_watchdog_generation += 1
        generation = self._chronograph_watchdog_generation

        def run():
            while generation == self._chronograph_watchdog_generation:
                time.sleep(1.0)
                if generation != self._chronograph_watchdog_generation:
                    return
                try:
                    self._ensure_chronograph_monitor_running_for_active_display()
                except Exception as exc:
                    decky.logger.info(f"Chronograph watchdog skipped: {exc}")

        thread = threading.Thread(target=run, name="jsaux-chronograph-watchdog", daemon=True)
        thread.start()

    def _chronograph_elapsed_seconds(self) -> int:
        total = max(1, int(self._chronograph_total_seconds))
        return max(0, min(total, int(time.time() - self._chronograph_started_at)))

    def _chronograph_asset_name(self, elapsed_seconds: int | None = None) -> str:
        elapsed = self._chronograph_elapsed_seconds() if elapsed_seconds is None else int(elapsed_seconds)
        return f"plugin-chronograph-{elapsed % 60:02d}.bmp"

    def _is_chronograph_asset(self, asset: str) -> bool:
        return asset == "plugin-chronograph.gif" or bool(re.fullmatch(r"plugin-chronograph-\d{2}\.(gif|bmp)", asset))

    def _current_custom_asset(self) -> str:
        try:
            settings = self.client.get("/v1/settings/display")
            if isinstance(settings.get("displaySettings"), dict):
                settings = settings["displaySettings"]
            active_module = str(settings.get("activeModuleId") or settings.get("active_module_id") or "")
            if active_module.lower() not in {"custom", "custom_upload"}:
                return ""
            custom = settings.get("custom", {})
            if isinstance(custom, dict):
                return str(custom.get("current_asset") or custom.get("currentAsset") or "")
        except Exception as exc:
            decky.logger.info(f"Current custom asset check failed: {exc}")
        return ""

    def _current_custom_asset_is(self, asset: str) -> bool:
        return self._current_custom_asset() == asset

    def _current_custom_asset_is_chronograph(self) -> bool:
        return self._is_chronograph_asset(self._current_custom_asset())

    def _display_update_requests_custom(self, payload: dict) -> bool:
        active_module = str(payload.get("activeModuleId") or payload.get("active_module_id") or "")
        if active_module.lower() == "custom":
            return True
        custom = payload.get("custom", {})
        if isinstance(custom, dict):
            current_asset = str(custom.get("current_asset") or custom.get("currentAsset") or "")
            return self._is_chronograph_asset(current_asset)
        return False

    def _settings_have_active_chronograph(self, settings: dict) -> bool:
        active_module = str(settings.get("activeModuleId") or settings.get("active_module_id") or "")
        custom = settings.get("custom", {})
        current_asset = ""
        if isinstance(custom, dict):
            current_asset = str(custom.get("current_asset") or custom.get("currentAsset") or "")
        return active_module.lower() == "custom" and self._is_chronograph_asset(current_asset)

    def _crc16_kermit(self, data: bytes) -> int:
        crc = 0
        for byte in data:
            crc ^= byte
            for _ in range(8):
                crc = ((crc >> 1) ^ 0x8408) if (crc & 1) else (crc >> 1)
        return crc & 0xFFFF

    def _standard_frame(self, transport_type: int, command: int, payload: bytes) -> bytes:
        frame = bytes([0x44, 0x59, transport_type & 0xFF, command & 0xFF]) + len(payload).to_bytes(2, "big") + payload
        return frame + self._crc16_kermit(frame).to_bytes(2, "big")

    def _encode_gif_upload(self, gif_data: bytes, chunk_size: int = 498) -> list[bytes]:
        import zlib

        frames = [self._standard_frame(0x01, 0x04, len(gif_data).to_bytes(4, "big") + zlib.crc32(gif_data).to_bytes(4, "big"))]
        sequence = 0
        for offset in range(0, len(gif_data), chunk_size):
            chunk = gif_data[offset : offset + chunk_size]
            payload = sequence.to_bytes(2, "big") + chunk
            frames.append(self._standard_frame(0x02, 0x02, payload))
            sequence = (sequence + 1) & 0xFFFF
        frames.append(self._standard_frame(0x01, 0x0B, b"\x01"))
        return frames

    def _build_dashboard_gif(self) -> bytes:
        width, height = 64, 54
        palette = [
            (0, 0, 0),
            (255, 255, 255),
            (65, 65, 65),
            (33, 32, 33),
            (255, 85, 0),
            (255, 0, 0),
            (255, 130, 0),
            (0, 0, 0),
        ]
        pixels = self._render_dashboard_pixels(time.localtime(), self._sample_dashboard_metrics())
        return self._gif_from_indexed(width, height, palette, pixels)

    def _build_hardware_monitor_gif(self) -> bytes:
        width, height = 64, 54
        palette = [
            (0, 0, 0),
            (255, 255, 255),
            (65, 65, 65),
            (255, 128, 0),
            (255, 0, 0),
            (0, 0, 0),
            (0, 0, 0),
            (0, 0, 0),
        ]
        bg, white, gray, orange, red = range(5)
        pixels = [bg] * (width * height)

        def dot(x: int, y: int, color: int):
            if 0 <= x < width and 0 <= y < height:
                pixels[y * width + x] = color

        def rect(x: int, y: int, w: int, h: int, color: int):
            for yy in range(y, y + h):
                for xx in range(x, x + w):
                    dot(xx, yy, color)

        glyphs = {
            "0": [31, 17, 17, 17, 17, 17, 31],
            "1": [4, 12, 4, 4, 4, 4, 31],
            "2": [31, 1, 1, 31, 16, 16, 31],
            "3": [31, 1, 1, 15, 1, 1, 31],
            "4": [17, 17, 17, 31, 1, 1, 1],
            "5": [31, 16, 16, 31, 1, 1, 31],
            "6": [31, 16, 16, 31, 17, 17, 31],
            "7": [31, 1, 2, 4, 4, 4, 4],
            "8": [31, 17, 17, 31, 17, 17, 31],
            "9": [31, 17, 17, 31, 1, 1, 31],
            "A": [14, 17, 17, 31, 17, 17, 17],
            "C": [31, 16, 16, 16, 16, 16, 31],
            "F": [31, 16, 16, 30, 16, 16, 16],
            "G": [31, 16, 16, 23, 17, 17, 31],
            "M": [17, 27, 21, 21, 17, 17, 17],
            "P": [30, 17, 17, 30, 16, 16, 16],
            "R": [30, 17, 17, 30, 20, 18, 17],
            "S": [31, 16, 16, 31, 1, 1, 31],
            "U": [17, 17, 17, 17, 17, 17, 31],
            "%": [17, 1, 2, 4, 8, 16, 17],
        }

        def text_width(text: str) -> int:
            return 0 if not text else len(text) * 6 - 1

        def text5(text: str, x: int, y: int, color: int = white):
            cx = x
            for ch in text.upper():
                if ch == " ":
                    cx += 6
                    continue
                rows = glyphs.get(ch)
                if rows:
                    for yy, bits in enumerate(rows):
                        for xx in range(5):
                            if bits & (1 << (4 - xx)):
                                dot(cx + xx, y + yy, color)
                cx += 6

        def right_text(text: str, right_x: int, y: int):
            text5(text, right_x - text_width(text) + 1, y)

        def bar(x: int, y: int, w: int, percent: int):
            for tick_x in range(x, x + w, 5):
                rect(tick_x, y - 1, 1, 3, gray)
            if percent < 0:
                return
            percent = max(0, min(100, percent))
            filled = max(0, min(w, percent * w // 100))
            if filled:
                rect(x, y, filled, 2, orange)
            rect(max(x, min(x + filled, x + w - 1)), y, 1, 2, red)

        gpu, cpu, ram, fps = self._sample_dashboard_metrics()
        right_text(f"{fps if fps >= 0 else '--'} FPS", 62, 2)

        bar(2, 12, 39, gpu)
        text5("GPU", 2, 17)
        right_text(f"{gpu if gpu >= 0 else '--'}%", 62, 17)

        bar(2, 26, 39, cpu)
        text5("CPU", 2, 31)
        right_text(f"{cpu if cpu >= 0 else '--'}%", 62, 31)

        bar(2, 40, 39, ram)
        text5("RAM", 2, 45)
        right_text(f"{ram if ram >= 0 else '--'}%", 62, 45)

        return self._gif_from_indexed(width, height, palette, pixels)

    def _build_clock_monitor_gif(self) -> bytes:
        width, height = 64, 54
        palette = [
            (0, 0, 0),
            (255, 255, 255),
            (65, 65, 65),
            (255, 215, 0),
            (0, 191, 255),
            (255, 0, 0),
            (255, 87, 51),
            (0, 0, 0),
        ]
        bg, white, gray, yellow, blue, red, orange = range(7)
        pixels = [bg] * (width * height)

        def dot(x: int, y: int, color: int):
            if 0 <= x < width and 0 <= y < height:
                pixels[y * width + x] = color

        def rect(x: int, y: int, w: int, h: int, color: int):
            for yy in range(y, y + h):
                for xx in range(x, x + w):
                    dot(xx, yy, color)

        tiny = {
            "0": [7, 5, 5, 5, 7], "1": [2, 6, 2, 2, 7], "2": [7, 1, 7, 4, 7], "3": [7, 1, 7, 1, 7],
            "4": [5, 5, 7, 1, 1], "5": [7, 4, 7, 1, 7], "6": [7, 4, 7, 5, 7], "7": [7, 1, 2, 2, 2],
            "8": [7, 5, 7, 5, 7], "9": [7, 5, 7, 1, 7], "A": [2, 5, 7, 5, 5], "B": [6, 5, 6, 5, 6],
            "C": [7, 4, 4, 4, 7], "D": [6, 5, 5, 5, 6], "E": [7, 4, 6, 4, 7], "F": [7, 4, 6, 4, 4],
            "H": [5, 5, 7, 5, 5], "I": [7, 2, 2, 2, 7], "L": [4, 4, 4, 4, 7], "M": [5, 7, 7, 5, 5], "N": [5, 7, 7, 7, 5],
            "O": [7, 5, 5, 5, 7], "P": [7, 5, 7, 4, 4], "R": [7, 5, 7, 6, 5], "S": [7, 4, 7, 1, 7],
            "T": [7, 2, 2, 2, 2], "U": [5, 5, 5, 5, 7], "W": [5, 5, 7, 7, 5], "Y": [5, 5, 2, 2, 2],
            "-": [0, 0, 7, 0, 0],
        }

        def text3(text: str, x: int, y: int, color: int = white):
            cx = x
            for ch in text.upper():
                if ch == " ":
                    cx += 4
                    continue
                rows = tiny.get(ch)
                if rows:
                    for yy, bits in enumerate(rows):
                        for xx in range(3):
                            if bits & (1 << (2 - xx)):
                                dot(cx + xx, y + yy, color)
                cx += 4

        big = {
            "0": [31, 17, 17, 17, 17, 17, 31],
            "1": [4, 12, 4, 4, 4, 4, 31],
            "2": [31, 1, 1, 31, 16, 16, 31],
            "3": [31, 1, 1, 15, 1, 1, 31],
            "4": [17, 17, 17, 31, 1, 1, 1],
            "5": [31, 16, 16, 31, 1, 1, 31],
            "6": [31, 16, 16, 31, 17, 17, 31],
            "7": [31, 1, 2, 4, 4, 4, 4],
            "8": [31, 17, 17, 31, 17, 17, 31],
            "9": [31, 17, 17, 31, 1, 1, 31],
        }

        def big_char(ch: str, x: int, y: int):
            if ch == " ":
                return
            rows = big.get(ch)
            if not rows:
                return
            for yy, bits in enumerate(rows):
                for xx in range(5):
                    if bits & (1 << (4 - xx)):
                        rect(x + xx * 2, y + yy * 2, 2, 2, white)

        sunny = [0b00011000, 0b01011010, 0b00111100, 0b11111111, 0b11111111, 0b00111100, 0b01011010, 0b00011000]
        for yy, bits in enumerate(sunny):
            for xx in range(8):
                if bits & (1 << (7 - xx)):
                    dot(54 + xx, 2 + yy, yellow)

        now = time.localtime()
        months = ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
        weekdays = ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")
        text3(f"{months[now.tm_mon - 1]} {now.tm_mday:02d} - {weekdays[now.tm_wday]}", 2, 2)
        text3("AM" if now.tm_hour < 12 else "PM", 2, 14)
        hour = now.tm_hour % 12 or 12
        hour_text = f"{hour:02d}"
        minute_text = f"{now.tm_min:02d}"

        time_center_top = 20
        time_center_height = 26
        digit_width = 10
        digit_gap = 2
        colon_width = 2
        colon_gap = 3
        time_y = time_center_top + (time_center_height - 14) // 2
        colon_x = (width // 2) - (colon_width // 2)
        side_width = digit_width * 2 + digit_gap
        hour_x = colon_x - colon_gap - side_width
        minute_x = colon_x + colon_width + colon_gap

        big_char(hour_text[0], hour_x, time_y)
        big_char(hour_text[1], hour_x + digit_width + digit_gap, time_y)
        if (int(time.time() * 1000) // 500) % 2 == 0:
            rect(colon_x, time_y + 4, colon_width, 3, white)
            rect(colon_x, time_y + 12, colon_width, 3, white)
        big_char(minute_text[0], minute_x, time_y)
        big_char(minute_text[1], minute_x + digit_width + digit_gap, time_y)

        for i in range(30):
            x = 3 + i * 2
            dot(x, 49, gray)
            dot(x, 51, gray)
        second = now.tm_sec
        active = second % 30
        y = 49 if second < 30 else 51
        rect(3 + active * 2, y, 2, 2, red)

        return self._gif_from_indexed(width, height, palette, pixels)

    def _build_weather_forecast_gif(self) -> bytes:
        width, height = 64, 54
        palette = [
            (0, 0, 0),
            (255, 255, 255),
            (255, 215, 0),
            (211, 84, 0),
            (157, 223, 255),
            (132, 132, 132),
            (0, 128, 255),
            (255, 235, 59),
        ]
        bg, white, sun_body, sun_ray, blue, gray, rain_blue, bolt = range(8)
        pixels = [bg] * (width * height)

        def dot(x: int, y: int, color: int):
            if 0 <= x < width and 0 <= y < height:
                pixels[y * width + x] = color

        def rect(x: int, y: int, w: int, h: int, color: int):
            for yy in range(y, y + h):
                for xx in range(x, x + w):
                    dot(xx, yy, color)

        tiny = {
            "0": [7, 5, 5, 5, 7], "1": [2, 6, 2, 2, 7], "2": [7, 1, 7, 4, 7], "3": [7, 1, 7, 1, 7],
            "4": [5, 5, 7, 1, 1], "5": [7, 4, 7, 1, 7], "6": [7, 4, 7, 5, 7], "7": [7, 1, 2, 2, 2],
            "8": [7, 5, 7, 5, 7], "9": [7, 5, 7, 1, 7], "A": [2, 5, 7, 5, 5], "B": [6, 5, 6, 5, 6],
            "C": [7, 4, 4, 4, 7], "D": [6, 5, 5, 5, 6], "E": [7, 4, 6, 4, 7], "F": [7, 4, 6, 4, 4],
            "G": [7, 4, 5, 5, 7], "H": [5, 5, 7, 5, 5], "I": [7, 2, 2, 2, 7], "K": [5, 5, 6, 5, 5],
            "L": [4, 4, 4, 4, 7], "M": [5, 7, 5, 5, 5], "N": [5, 7, 7, 7, 5], "O": [7, 5, 5, 5, 7],
            "P": [7, 5, 7, 4, 4], "R": [7, 5, 7, 6, 5], "S": [7, 4, 7, 1, 7], "T": [7, 2, 2, 2, 2],
            "U": [5, 5, 5, 5, 7], "W": [5, 5, 7, 7, 5], "Y": [5, 5, 2, 2, 2], "-": [0, 0, 7, 0, 0],
            "%": [5, 1, 2, 4, 5],
        }

        def text3(text: str, x: int, y: int, color: int = white, max_chars: int | None = None):
            cx = x
            for ch in text.upper()[:max_chars]:
                if ch == " ":
                    cx += 2
                    continue
                rows = tiny.get(ch)
                if rows:
                    for yy, bits in enumerate(rows):
                        for xx in range(3):
                            if bits & (1 << (2 - xx)):
                                dot(cx + xx, y + yy, color)
                cx += 4

        def mini_icon(kind: str, x: int, y: int):
            if kind == "sun":
                bitmap = [0b00011000, 0b01011010, 0b00111100, 0b11111111, 0b11111111, 0b00111100, 0b01011010, 0b00011000]
                for yy, bits in enumerate(bitmap):
                    for xx in range(8):
                        if bits & (1 << (7 - xx)):
                            dot(x + xx, y + yy, sun_ray if yy < 2 or yy > 5 or xx < 2 or xx > 5 else sun_body)
            elif kind == "rain":
                bitmap = [0b00111000, 0b01111100, 0b11111110, 0b01111110, 0, 0b01001000, 0b00100100, 0b01001000]
                for yy, bits in enumerate(bitmap):
                    for xx in range(8):
                        if bits & (1 << (7 - xx)):
                            dot(x + xx, y + yy, gray if yy < 4 else rain_blue)
            else:
                bitmap = [0b00111000, 0b01111100, 0b11111110, 0b01110110, 0b00011000, 0b00110000, 0b01100000, 0b01000000]
                for yy, bits in enumerate(bitmap):
                    for xx in range(8):
                        if bits & (1 << (7 - xx)):
                            dot(x + xx, y + yy, bolt if yy >= 4 or xx >= 4 else gray)

        def large_sun(cx: int, cy: int):
            for x, y, w, h in [(cx - 2, cy - 12, 5, 3), (cx - 2, cy + 10, 5, 3), (cx - 12, cy - 2, 3, 5), (cx + 10, cy - 2, 3, 5)]:
                rect(x, y, w, h, sun_ray)
            for x, y in [(cx - 9, cy - 9), (cx + 7, cy - 9), (cx - 9, cy + 7), (cx + 7, cy + 7)]:
                rect(x, y, 3, 3, sun_ray)
            for yy in range(-10, 11):
                for xx in range(-10, 11):
                    d2 = xx * xx + yy * yy
                    if d2 <= 92:
                        dot(cx + xx, cy + yy, sun_ray if d2 > 58 else sun_body)
            rect(cx - 15, cy + 1, 7, 6, blue)
            rect(cx - 9, cy - 2, 10, 8, white)
            rect(cx - 3, cy + 1, 9, 6, gray)
            rect(cx - 13, cy + 5, 20, 5, white)
            for i in range(3):
                rect(cx - 11 + i * 6, cy + 11, 2, 2, rain_blue)

        now = time.localtime()
        months = ("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
        weekdays = ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")
        text3(f"{months[now.tm_mon - 1]}{now.tm_mday:02d}-{weekdays[now.tm_wday]}", 0, 2, white)
        text3("CLR", 0, 11, white)
        large_sun(20, 28)
        for idx, kind in enumerate(("sun", "rain", "thunder")):
            row_y = (0, 14, 28)[idx]
            day = weekdays[(now.tm_wday + idx + 1) % 7]
            text3(day, 42, row_y + 2, white)
            mini_icon(kind, 55, row_y)
        text3("30C", 1, 43, white)
        text3("TEMP", 0, 49, white)
        text3("60%", 22, 43, white)
        text3("RH", 22, 49, white)
        text3("25KMH", 40, 43, white)
        text3("WS", 40, 49, white)

        return self._gif_from_indexed(width, height, palette, pixels)

    def _build_playtime_monitor_gif(self) -> bytes:
        width, height = 64, 54
        palette = [
            (0, 0, 0),
            (255, 255, 255),
            (102, 102, 102),
            (255, 0, 0),
            (100, 0, 255),
            (255, 240, 0),
            (255, 0, 180),
            (250, 145, 0),
            (250, 237, 0),
        ]
        bg, white, gray, red, purple, yellow, pink, orange, trophy_yellow = range(9)
        pixels = [bg] * (width * height)

        def dot(x: int, y: int, color: int):
            if 0 <= x < width and 0 <= y < height:
                pixels[y * width + x] = color

        def rect(x: int, y: int, w: int, h: int, color: int):
            for yy in range(y, y + h):
                for xx in range(x, x + w):
                    dot(xx, yy, color)

        tiny = {
            "0": [7, 5, 5, 5, 7], "1": [2, 6, 2, 2, 7], "2": [7, 1, 7, 4, 7],
            "3": [7, 1, 7, 1, 7], "4": [5, 5, 7, 1, 1], "5": [7, 4, 7, 1, 7],
            "6": [7, 4, 7, 5, 7], "7": [7, 1, 2, 2, 2], "8": [7, 5, 7, 5, 7],
            "9": [7, 5, 7, 1, 7], "A": [2, 5, 7, 5, 5], "B": [6, 5, 6, 5, 6],
            "C": [7, 4, 4, 4, 7], "D": [6, 5, 5, 5, 6], "E": [7, 4, 6, 4, 7],
            "F": [7, 4, 6, 4, 4], "G": [7, 4, 5, 5, 7], "H": [5, 5, 7, 5, 5],
            "I": [7, 2, 2, 2, 7], "K": [5, 5, 6, 5, 5], "L": [4, 4, 4, 4, 7],
            "M": [5, 7, 7, 5, 5], "N": [5, 7, 7, 7, 5], "O": [7, 5, 5, 5, 7],
            "P": [7, 5, 7, 4, 4], "R": [7, 5, 7, 6, 5], "S": [7, 4, 7, 1, 7],
            "T": [7, 2, 2, 2, 2], "U": [5, 5, 5, 5, 7], "V": [5, 5, 5, 5, 2],
            "W": [5, 5, 7, 7, 5], "Y": [5, 5, 2, 2, 2], "-": [0, 0, 7, 0, 0],
            " ": [0, 0, 0, 0, 0],
        }
        medium = {
            "0": [0b011110, 0b111111, 0b110011, 0b110011, 0b110011, 0b110011, 0b111111, 0b011110],
            "1": [0b111000, 0b111100, 0b001100, 0b001100, 0b001100, 0b001100, 0b111111, 0b111111],
            "2": [0b011111, 0b111111, 0b000011, 0b011111, 0b111110, 0b110000, 0b111111, 0b011111],
            "3": [0b011111, 0b111111, 0b000011, 0b011111, 0b011111, 0b000011, 0b111111, 0b011110],
            "4": [0b110011, 0b110011, 0b110011, 0b111111, 0b011111, 0b000011, 0b000011, 0b000011],
            "5": [0b011111, 0b111111, 0b110000, 0b111110, 0b011111, 0b000011, 0b111111, 0b111110],
            "6": [0b011111, 0b111111, 0b110000, 0b111110, 0b111111, 0b110011, 0b111111, 0b011110],
            "7": [0b111110, 0b111111, 0b000011, 0b000011, 0b000011, 0b000011, 0b000011, 0b000011],
            "8": [0b011110, 0b111111, 0b110011, 0b111111, 0b111111, 0b110011, 0b111111, 0b011110],
            "9": [0b011110, 0b111111, 0b110011, 0b111111, 0b011111, 0b000011, 0b111111, 0b111110],
        }

        def tiny_width(text: str) -> int:
            return 0 if not text else len(text) * 4 - 1

        def draw_tiny(text: str, x: int, y: int, color: int = white):
            cx = x
            for ch in text.upper():
                rows = tiny.get(ch, tiny[" "])
                for yy, bits in enumerate(rows):
                    for xx in range(3):
                        if bits & (1 << (2 - xx)):
                            dot(cx + xx, y + yy, color)
                cx += 4

        def split_title(title: str) -> tuple[str, str] | None:
            title = " ".join(title.upper().split())
            if tiny_width(title) <= 60:
                return None
            words = title.split(" ")
            first = ""
            second = ""
            for word in words:
                candidate = word if not first else f"{first} {word}"
                if tiny_width(candidate) <= 60 or not first:
                    first = candidate
                else:
                    second = word if not second else f"{second} {word}"
            return first[:15], second[:15]

        def draw_tiny_time(text: str, right_x: int, y: int):
            width_px = sum(2 if ch == ":" else 4 for ch in text[:5]) - 1
            x = right_x - width_px + 1
            for ch in text[:5]:
                if ch == ":":
                    dot(x, y + 1, white)
                    dot(x, y + 3, white)
                    x += 2
                else:
                    draw_tiny(ch, x, y)
                    x += 4

        def draw_medium_digit(ch: str, x: int, y: int):
            rows = medium.get(ch)
            if not rows:
                return
            for yy, bits in enumerate(rows):
                for xx in range(6):
                    if bits & (1 << (5 - xx)):
                        dot(x + xx, y + yy, white)

        context = self._scan_context()
        title = context.get("title") or "STARDEW VALLEY"
        if len(title) < 4 or title.lower() in {"steam", "reaper"}:
            title = "STARDEW VALLEY"
        clean_title = " ".join(title.upper().split())
        if clean_title == "STARDEW VALLEY":
            draw_tiny("STARDEW", 2, 2)
            draw_tiny("VALLEY", 2, 9)
        else:
            split = split_title(clean_title)
            if split is None:
                draw_tiny(clean_title[:15], 2, 2)
            else:
                draw_tiny(split[0], 2, 2)
                draw_tiny(split[1], 2, 9)

        pad_rows = (
            ".....B...",
            "....B....",
            ".BBBBBBB.",
            "BBYBBBYBB",
            "BYYYBYBYB",
            "BBYBBBYBM",
            "BBBMBBBBM",
            ".BM...MM.",
        )
        for yy, row in enumerate(pad_rows):
            for xx, ch in enumerate(row):
                if ch == "B":
                    dot(2 + xx, 19 + yy, purple)
                elif ch == "Y":
                    dot(2 + xx, 19 + yy, yellow)
                elif ch == "M":
                    dot(2 + xx, 19 + yy, pink)

        app_id = context.get("appId", "")
        session_started_at = context.get("sessionStartedAt") or 0
        if app_id and app_id != self._playtime_current_app_id:
            self._playtime_current_app_id = app_id
            self._playtime_session_started_at = session_started_at or time.time()
        if session_started_at:
            self._playtime_session_started_at = float(session_started_at)

        session_minutes = max(0, int((time.time() - self._playtime_session_started_at) // 60))
        draw_tiny_time(f"{(session_minutes // 60) % 100:02d}:{session_minutes % 60:02d}", 61, 22)

        for tick_x in (2, 11, 21, 31, 41, 51, 61):
            dot(tick_x, 29, gray)
            dot(tick_x, 34, gray)
        dot(2, 30, gray)
        dot(2, 33, gray)
        for tick_x in range(6, 62, 5):
            dot(tick_x, 30, gray)
            dot(tick_x, 33, gray)
        filled = max(0, min(31, int((session_minutes % 300) * 40 / 300)))
        rect(2, 31, filled, 2, white)
        rect(2 + filled, 31, 1, 2, red)

        trophy_rows = (
            "..YYYYO..",
            "YYWYYYOYY",
            "Y.WYYYO.Y",
            "Y.WYYYO.Y",
            ".YYWYYOY.",
            "...YYO...",
            "....Y....",
            "....Y....",
            "..WYYYO..",
            ".YYYYYYO.",
        )
        for yy, row in enumerate(trophy_rows):
            for xx, ch in enumerate(row):
                if ch == "Y":
                    dot(2 + xx, 42 + yy, trophy_yellow)
                elif ch == "W":
                    dot(2 + xx, 42 + yy, white)
                elif ch == "O":
                    dot(2 + xx, 42 + yy, orange)

        total_minutes = max(0, int(context.get("totalPlaytimeMinutes") or 0))
        digits = f"{min(99999, (total_minutes + session_minutes) // 60):05d}" if total_minutes else "19806"
        x = 18
        for ch in digits:
            draw_medium_digit(ch, x, 43)
            x += 7
        small_h = (0b100, 0b100, 0b111, 0b101, 0b101)
        for yy, bits in enumerate(small_h):
            for xx in range(3):
                if bits & (1 << (2 - xx)):
                    dot(54 + xx, 46 + yy, white)
        rect(13, 42, 3, 1, gray)
        rect(13, 43, 1, 2, gray)
        dot(15, 44, gray)
        rect(13, 51, 3, 1, gray)
        rect(13, 49, 1, 2, gray)
        dot(15, 49, gray)
        rect(59, 42, 3, 1, gray)
        dot(59, 44, gray)
        rect(61, 43, 1, 2, gray)
        rect(59, 51, 3, 1, gray)
        dot(59, 49, gray)
        rect(61, 49, 1, 2, gray)

        return self._gif_from_indexed(width, height, palette, pixels)

    @staticmethod
    def _countdown_display_state(total: int, remaining: int) -> tuple[str, int, int]:
        total = max(1, int(total))
        remaining = max(0, min(total, int(remaining)))
        if total >= 3600:
            time_text = f"{min(99, remaining // 3600):02d}:{(remaining // 60) % 60:02d}"
            seconds_in_minute = remaining % 60
            bar_units = 60 if seconds_in_minute == 0 and remaining > 0 else seconds_in_minute
            return time_text, bar_units, 60
        if total >= 60:
            return f"{min(99, remaining // 60):02d}:{remaining % 60:02d}", 60, 60
        return f"00:{remaining:02d}", 60, 60

    def _build_countdown_monitor_gif(
        self,
        count_up: bool = False,
        elapsed_override: int | None = None,
        image_format: str = "gif",
    ) -> bytes:
        width, height = 64, 54
        palette = [
            (0, 0, 0),
            (255, 255, 255),
            (102, 102, 102),
            (255, 105, 0),
            (255, 0, 0),
            (160, 255, 0),
            (255, 105, 0),
            (96, 0, 255),
        ]
        bg, white, gray, orange, red, green, sand, purple = range(8)
        pixels = [bg] * (width * height)

        def dot(x: int, y: int, color: int):
            if 0 <= x < width and 0 <= y < height:
                pixels[y * width + x] = color

        def rect(x: int, y: int, w: int, h: int, color: int):
            for yy in range(y, y + h):
                for xx in range(x, x + w):
                    dot(xx, yy, color)

        tiny = {
            "0": [7, 5, 5, 5, 7], "1": [2, 6, 2, 2, 7], "2": [7, 1, 7, 4, 7], "3": [7, 1, 7, 1, 7],
            "4": [5, 5, 7, 1, 1], "5": [7, 4, 7, 1, 7], "6": [7, 4, 7, 5, 7], "7": [7, 1, 2, 2, 2],
            "8": [7, 5, 7, 5, 7], "9": [7, 5, 7, 1, 7], "A": [2, 5, 7, 5, 5], "C": [7, 4, 4, 4, 7],
            "D": [6, 5, 5, 5, 6], "E": [7, 4, 7, 4, 7], "I": [7, 2, 2, 2, 7], "M": [5, 7, 5, 5, 5],
            "N": [5, 7, 7, 7, 5], "O": [7, 5, 5, 5, 7], "R": [7, 5, 6, 5, 5], "S": [3, 4, 2, 1, 6], "T": [7, 2, 2, 2, 2],
            "U": [5, 5, 5, 5, 7], "W": [5, 5, 7, 7, 5],
        }

        def text3(text: str, x: int, y: int, color: int = white):
            cx = x
            for ch in text.upper():
                if ch == " ":
                    cx += 4
                    continue
                rows = tiny.get(ch)
                if rows:
                    for yy, bits in enumerate(rows):
                        for xx in range(3):
                            if bits & (1 << (2 - xx)):
                                dot(cx + xx, y + yy, color)
                cx += 4

        clock_big = {
            "0": (12, [0x7FE0, 0xFFF0, 0xFFF0, 0xFFF0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xFFF0, 0xFFF0, 0xFFF0, 0x7FE0]),
            "1": (12, [0x0F00, 0x0F00, 0x7F00, 0x7F00, 0x7F00, 0x7F00, 0x0F00, 0x0F00, 0x0F00, 0x0F00, 0x0F00, 0x0F00, 0x0F00, 0x0F00, 0x0F00, 0x0F00, 0xFFF0, 0xFFF0, 0xFFF0, 0xFFF0]),
            "2": (12, [0xFFE0, 0xFFF0, 0xFFF0, 0xFFF0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x7FF0, 0xFFF0, 0xFFF0, 0xFFE0, 0xF000, 0xF000, 0xF000, 0xF000, 0xFFF0, 0xFFF0, 0xFFF0, 0x7FF0]),
            "3": (12, [0xFFE0, 0xFFF0, 0xFFF0, 0xFFF0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0xFFF0, 0xFFF0, 0xFFF0, 0xFFF0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0xFFF0, 0xFFF0, 0xFFF0, 0xFFE0]),
            "4": (12, [0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xFFF0, 0xFFF0, 0xFFF0, 0x7FF0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0]),
            "5": (12, [0x7FF0, 0xFFF0, 0xFFF0, 0xFFF0, 0xF000, 0xF000, 0xF000, 0xF000, 0xFFE0, 0xFFF0, 0xFFF0, 0x7FF0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0xFFF0, 0xFFF0, 0xFFF0, 0xFFE0]),
            "6": (12, [0x7FF0, 0xFFF0, 0xFFF0, 0xFFF0, 0xF000, 0xF000, 0xF000, 0xF000, 0xFFE0, 0xFFF0, 0xFFF0, 0xFFF0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xFFF0, 0xFFF0, 0xFFF0, 0x7FE0]),
            "7": (12, [0xFFE0, 0xFFF0, 0xFFF0, 0xFFF0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0x00F0]),
            "8": (12, [0x7FE0, 0xFFF0, 0xFFF0, 0xFFF0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xFFF0, 0xFFF0, 0xFFF0, 0xFFF0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xFFF0, 0xFFF0, 0xFFF0, 0x7FE0]),
            "9": (12, [0x7FE0, 0xFFF0, 0xFFF0, 0xFFF0, 0xF0F0, 0xF0F0, 0xF0F0, 0xF0F0, 0xFFF0, 0xFFF0, 0xFFF0, 0x7FF0, 0x00F0, 0x00F0, 0x00F0, 0x00F0, 0xFFF0, 0xFFF0, 0xFFF0, 0xFFE0]),
            ":": (4, [0x0000, 0x0000, 0x0000, 0x0000, 0xF000, 0xF000, 0xF000, 0xF000, 0x0000, 0x0000, 0x0000, 0x0000, 0xF000, 0xF000, 0xF000, 0xF000, 0x0000, 0x0000, 0x0000, 0x0000]),
        }

        def clock_big_char(ch: str, x: int, y: int):
            glyph = clock_big.get(ch)
            if not glyph:
                return
            glyph_width, rows = glyph
            for yy, bits in enumerate(rows):
                for xx in range(glyph_width):
                    if bits & (1 << (15 - xx)):
                        dot(x + xx, y + yy, white)

        def hourglass(x: int, y: int):
            rows = (
                "GGGGG",
                "GOOOG",
                ".GOG.",
                "..G..",
                ".G.G.",
                "G.O.G",
                "GGGGG",
            )
            for yy, row in enumerate(rows):
                for xx, ch in enumerate(row):
                    if ch == "G":
                        dot(x + xx, y + yy, green)
                    elif ch == "O":
                        dot(x + xx, y + yy, sand)

        def timer_icon(x: int, y: int):
            rows = (
                "..GGG..",
                ".GPPPG.",
                "GPPGPPG",
                "GPPGGPG",
                "GPPPPPG",
                ".GPPPG.",
                "..GGG..",
            )
            for yy, row in enumerate(rows):
                for xx, ch in enumerate(row):
                    if ch == "G":
                        dot(x + xx, y + yy, green)
                    elif ch == "P":
                        dot(x + xx, y + yy, purple)

        if count_up:
            total = max(1, int(self._chronograph_total_seconds))
            elapsed = elapsed_override if elapsed_override is not None else int(time.time() - self._chronograph_started_at)
            elapsed = max(0, min(total, int(elapsed)))
            time_text = f"{(elapsed // 3600) % 100:02d}:{(elapsed // 60) % 60:02d}"
            bar_units = elapsed % 60
            bar_total = 60
        else:
            total = max(1, int(self._countdown_total_seconds))
            elapsed = max(0, min(total, int(time.time() - self._countdown_started_at)))
            remaining = max(0, total - elapsed)
            time_text, bar_units, bar_total = self._countdown_display_state(total, remaining)
            label_text = f"{total}S" if total < 60 else f"{max(1, total // 60):02d}MIN"
        if count_up:
            text3("TIMER", 2, 2)
            timer_icon(55, 2)
        else:
            text3("COUNTDOWN", 2, 2)
            if total < 60:
                text3(f"{total}", 2, 9)
                tiny_s = (3, 4, 2, 1, 6)
                for yy, bits in enumerate(tiny_s):
                    for xx in range(3):
                        if bits & (1 << (2 - xx)):
                            dot(11 + xx, 9 + yy, white)
            else:
                text3(label_text, 2, 9)
            hourglass(57, 2)

        clock_big_char(time_text[0], 2, 18)
        clock_big_char(time_text[1], 16, 18)
        clock_big_char(":", 30, 18)
        clock_big_char(time_text[3], 36, 18)
        clock_big_char(time_text[4], 50, 18)

        bar_x, bar_y, bar_w = 2, 48, 60
        if count_up:
            for tick_x in [bar_x, *range(bar_x + 9, bar_x + bar_w, 10)]:
                dot(tick_x, bar_y - 2, gray)
                dot(tick_x, bar_y + 3, gray)
            for tick_x in [bar_x, *range(bar_x + 4, bar_x + bar_w, 5)]:
                dot(tick_x, bar_y - 1, gray)
                dot(tick_x, bar_y + 2, gray)
        else:
            for tick_x in range(bar_x + 2, bar_x + bar_w, 3):
                dot(tick_x, bar_y - 1, gray)
                dot(tick_x, bar_y + 2, gray)
            for tick_x in range(bar_x + 5, bar_x + bar_w, 6):
                dot(tick_x, bar_y - 2, gray)
                dot(tick_x, bar_y + 3, gray)
        if count_up:
            current_width = max(1, min(bar_w, (bar_units + 1) * bar_w // bar_total))
        else:
            current_width = max(0, min(bar_w, bar_units * bar_w // bar_total))
        if current_width:
            rect(bar_x, bar_y, current_width, 2, orange)
        cursor_x = bar_x if current_width <= 0 else min(bar_x + bar_w - 1, bar_x + current_width - 1)
        rect(cursor_x, bar_y, 1, 2, red)

        if image_format == "bmp":
            return self._bmp_from_indexed(width, height, palette, pixels)
        return self._gif_from_indexed(width, height, palette, pixels)

    def _build_chronograph_monitor_gif(self) -> bytes:
        return self._build_countdown_monitor_gif(count_up=True)

    def _build_chronograph_monitor_asset(self) -> bytes:
        return self._build_countdown_monitor_gif(count_up=True, image_format="bmp")

    def _build_dashboard_animated_gif(self) -> bytes:
        width, height = 64, 54
        palette = [
            (0, 0, 0),
            (255, 255, 255),
            (65, 65, 65),
            (33, 32, 33),
            (255, 85, 0),
            (255, 0, 0),
            (255, 130, 0),
            (0, 0, 0),
        ]
        metrics = self._sample_dashboard_metrics()
        start = int(time.time())
        frames = [self._render_dashboard_pixels(time.localtime(start + offset), metrics) for offset in range(30)]
        return self._gif_from_rgb222_frames(width, height, palette, frames, delay_cs=100)

    def _render_dashboard_pixels(self, now, metrics: tuple[int, int, int, int]) -> list[int]:
        width, height = 64, 54
        bg, white, gray, dim, orange, red, sun = range(7)
        pixels = [bg] * (width * height)

        def dot(x: int, y: int, color: int):
            if 0 <= x < width and 0 <= y < height:
                pixels[y * width + x] = color

        def rect(x: int, y: int, w: int, h: int, color: int):
            for yy in range(y, y + h):
                for xx in range(x, x + w):
                    dot(xx, yy, color)

        tiny = {
            "0": [7, 5, 5, 5, 7], "1": [2, 6, 2, 2, 7], "2": [7, 1, 7, 4, 7], "3": [7, 1, 7, 1, 7],
            "4": [5, 5, 7, 1, 1], "5": [7, 4, 7, 1, 7], "6": [7, 4, 7, 5, 7], "7": [7, 1, 2, 2, 2],
            "8": [7, 5, 7, 5, 7], "9": [7, 5, 7, 1, 7], "A": [2, 5, 7, 5, 5], "B": [6, 5, 6, 5, 6],
            "C": [7, 4, 4, 4, 7], "D": [6, 5, 5, 5, 6], "E": [7, 4, 6, 4, 7], "F": [7, 4, 6, 4, 4],
            "G": [7, 4, 5, 5, 7], "H": [5, 5, 7, 5, 5], "I": [7, 2, 2, 2, 7], "J": [1, 1, 1, 5, 7],
            "K": [5, 5, 6, 5, 5], "L": [4, 4, 4, 4, 7], "M": [5, 7, 7, 5, 5], "N": [5, 7, 7, 7, 5],
            "O": [7, 5, 5, 5, 7], "P": [7, 5, 7, 4, 4], "R": [7, 5, 7, 6, 5], "S": [7, 4, 7, 1, 7],
            "T": [7, 2, 2, 2, 2], "U": [5, 5, 5, 5, 7], "V": [5, 5, 5, 5, 2], "W": [5, 5, 7, 7, 5],
            "X": [5, 5, 2, 5, 5], "Y": [5, 5, 2, 2, 2], "Z": [7, 1, 2, 4, 7], "%": [5, 1, 2, 4, 5],
            "-": [0, 0, 7, 0, 0], ":": [0, 2, 0, 2, 0],
        }

        def text3(text: str, x: int, y: int, color: int = white):
            cx = x
            for ch in text.upper():
                if ch == " ":
                    cx += 4
                    continue
                rows = tiny.get(ch)
                if rows:
                    for yy, bits in enumerate(rows):
                        for xx in range(3):
                            if bits & (1 << (2 - xx)):
                                dot(cx + xx, y + yy, color)
                cx += 4

        large = {
            "0": [31, 17, 19, 21, 21, 25, 17, 17, 31], "1": [4, 12, 20, 4, 4, 4, 4, 4, 31],
            "2": [31, 1, 1, 31, 16, 16, 16, 16, 31], "3": [31, 1, 1, 15, 1, 1, 1, 1, 31],
            "4": [17, 17, 17, 31, 1, 1, 1, 1, 1], "5": [31, 16, 16, 31, 1, 1, 1, 1, 31],
            "6": [31, 16, 16, 31, 17, 17, 17, 17, 31], "7": [31, 1, 1, 2, 4, 4, 4, 4, 4],
            "8": [31, 17, 17, 31, 17, 17, 17, 17, 31], "9": [31, 17, 17, 31, 1, 1, 1, 1, 31],
        }

        def time_text(value: str, x: int, y: int):
            cx = x
            blink = now.tm_sec % 2 == 0
            for ch in value:
                if ch == ":":
                    if blink:
                        rect(cx, y + 2, 1, 2, white)
                        rect(cx, y + 6, 1, 2, white)
                    cx += 2
                    continue
                rows = large.get(ch)
                if rows:
                    for yy, bits in enumerate(rows):
                        for xx in range(5):
                            if bits & (1 << (4 - xx)):
                                dot(cx + xx, y + yy, white)
                cx += 6

        text3(time.strftime("%b %d - %a", now).upper(), 0, 0)
        text3(time.strftime("%p", now).upper(), 56, 0)
        sun_rows = ["..1..1..", "...11...", ".111111.", "..1111..", "11111111", "..1111..", ".111111.", "...11..."]
        for yy, row in enumerate(sun_rows):
            for xx, ch in enumerate(row):
                if ch == "1":
                    dot(1 + xx, 12 + yy, sun)
        hour = now.tm_hour % 12 or 12
        minute = now.tm_min
        value = f"{hour:02d}:{minute:02d}"
        time_text(value, 64 - 25 - 1, 11)

        for i in range(30):
            x = 2 + i * 2
            dot(x, 24, gray)
            dot(x, 26, gray)
            dot(x, 28, gray)
        dot(2 + min(29, now.tm_sec // 2) * 2, 26, red)

        gpu, cpu, ram, fps = metrics

        def metric(label: str, val: str, percent: int, x: int, y: int, bar_y: int, draw_bar: bool):
            text3(f"{label} {val}", x, y)
            if draw_bar:
                rect(x, bar_y - 1, 27, 2, dim)
                if percent < 0:
                    return
                fill = max(1, min(27, int(27 * max(0, min(100, percent)) / 100)))
                rect(x, bar_y - 1, fill, 2, orange)
                rect(x + fill - 1, bar_y - 1, 1, 2, red)

        metric("GPU", f"{gpu if gpu >= 0 else '--'}%", gpu, 1, 31, 40, True)
        metric("CPU", f"{cpu if cpu >= 0 else '--'}%", cpu, 34, 31, 40, True)
        metric("RAM", f"{ram if ram >= 0 else '--'}%", ram, 1, 44, 52, True)
        text3(f"FPS {fps if fps >= 0 else '--'}", 34, 44)
        for yy in range(51, 53, 2):
            for xx in range(34, 61, 2):
                dot(xx, yy, dim)

        return pixels

    def _sample_dashboard_metrics(self):
        """Return the same performance sample used by both native monitor modules.

        The daemon owns the system probes and refresh cadence.  Keeping this
        legacy GIF path on the daemon endpoint prevents it from silently
        falling back to guessed values or a different RAM/FPS definition.
        """

        def percent(value) -> int:
            try:
                normalized = int(float(value))
            except (TypeError, ValueError, OverflowError):
                return -1
            return normalized if 0 <= normalized <= 100 else -1

        def refresh_rate(value) -> int:
            try:
                normalized = int(float(value) + 0.5)
            except (TypeError, ValueError, OverflowError):
                return -1
            return normalized if 1 <= normalized <= 999 else -1

        try:
            payload = self.client.get("/v1/runtime/performance")
            system = payload.get("systemPerformance") if isinstance(payload, dict) else None
            dashboard = payload.get("dashboard") if isinstance(payload, dict) else None
            if not isinstance(system, dict):
                system = {}
            if not isinstance(dashboard, dict):
                dashboard = {}

            def metric_percent(name: str) -> int:
                value = system.get(f"{name}Percent")
                if value is None:
                    value = dashboard.get(f"{name}Percent")
                return percent(value)

            fps_value = payload.get("refreshRate") if isinstance(payload, dict) else None
            if fps_value in (None, ""):
                fps_value = system.get("fpsValue") or dashboard.get("fpsValue")
            return (
                metric_percent("gpu"),
                metric_percent("cpu"),
                metric_percent("ram"),
                refresh_rate(fps_value),
            )
        except Exception as exc:
            decky.logger.info(f"Performance sample unavailable: {exc}")
            return -1, -1, -1, -1

    def _gif_from_indexed(self, width: int, height: int, palette: list[tuple[int, int, int]], pixels: list[int]) -> bytes:
        min_code_size = max(2, (len(palette) - 1).bit_length())
        table_size = 1 << min_code_size
        palette = palette + [(0, 0, 0)] * (table_size - len(palette))
        color_table = bytearray()
        for red, green, blue in palette:
            color_table.extend([red, green, blue])

        image_data = self._gif_lzw(pixels, min_code_size)
        blocks = bytearray()
        for offset in range(0, len(image_data), 255):
            chunk = image_data[offset : offset + 255]
            blocks.append(len(chunk))
            blocks.extend(chunk)
        blocks.append(0)

        gif = bytearray(b"GIF89a")
        gif.extend(width.to_bytes(2, "little"))
        gif.extend(height.to_bytes(2, "little"))
        gif.extend(bytes([0xA0 | (min_code_size - 1), 0x00, 0x00]))
        gif.extend(color_table)
        gif.extend(b"\x2C\x00\x00\x00\x00")
        gif.extend(width.to_bytes(2, "little"))
        gif.extend(height.to_bytes(2, "little"))
        gif.append(0x00)
        gif.append(min_code_size)
        gif.extend(blocks)
        gif.append(0x3B)
        return bytes(gif)

    def _bmp_from_indexed(self, width: int, height: int, palette: list[tuple[int, int, int]], pixels: list[int]) -> bytes:
        row_stride = ((width * 3 + 3) // 4) * 4
        pixel_bytes = bytearray()
        for y in range(height - 1, -1, -1):
            row = bytearray()
            for x in range(width):
                red, green, blue = palette[pixels[y * width + x]]
                row.extend([blue, green, red])
            row.extend(b"\x00" * (row_stride - len(row)))
            pixel_bytes.extend(row)

        file_header_size = 14
        dib_header_size = 40
        pixel_offset = file_header_size + dib_header_size
        file_size = pixel_offset + len(pixel_bytes)

        bmp = bytearray(b"BM")
        bmp.extend(file_size.to_bytes(4, "little"))
        bmp.extend((0).to_bytes(4, "little"))
        bmp.extend(pixel_offset.to_bytes(4, "little"))
        bmp.extend(dib_header_size.to_bytes(4, "little"))
        bmp.extend(width.to_bytes(4, "little", signed=True))
        bmp.extend(height.to_bytes(4, "little", signed=True))
        bmp.extend((1).to_bytes(2, "little"))
        bmp.extend((24).to_bytes(2, "little"))
        bmp.extend((0).to_bytes(4, "little"))
        bmp.extend(len(pixel_bytes).to_bytes(4, "little"))
        bmp.extend((2835).to_bytes(4, "little", signed=True))
        bmp.extend((2835).to_bytes(4, "little", signed=True))
        bmp.extend((0).to_bytes(4, "little"))
        bmp.extend((0).to_bytes(4, "little"))
        bmp.extend(pixel_bytes)
        return bytes(bmp)

    def _gif_from_indexed_frames(
        self,
        width: int,
        height: int,
        palette: list[tuple[int, int, int]],
        frames: list[list[int]],
        delay_cs: int,
    ) -> bytes:
        color_table = bytearray()
        for red, green, blue in palette:
            color_table.extend([red, green, blue])

        min_code_size = 3
        gif = bytearray(b"GIF89a")
        gif.extend(width.to_bytes(2, "little"))
        gif.extend(height.to_bytes(2, "little"))
        gif.extend(bytes([0xA2, 0x00, 0x00]))
        gif.extend(color_table)
        gif.extend(b"\x21\xFF\x0BNETSCAPE2.0\x03\x01\x00\x00\x00")

        for pixels in frames:
            image_data = self._gif_lzw(pixels, min_code_size)
            blocks = bytearray()
            for offset in range(0, len(image_data), 255):
                chunk = image_data[offset : offset + 255]
                blocks.append(len(chunk))
                blocks.extend(chunk)
            blocks.append(0)

            gif.extend(b"\x21\xF9\x04\x04")
            gif.extend(int(delay_cs).to_bytes(2, "little"))
            gif.extend(b"\x00\x00")
            gif.extend(b"\x2C\x00\x00\x00\x00")
            gif.extend(width.to_bytes(2, "little"))
            gif.extend(height.to_bytes(2, "little"))
            gif.append(0x00)
            gif.append(min_code_size)
            gif.extend(blocks)

        gif.append(0x3B)
        return bytes(gif)

    def _gif_from_rgb222_frames(
        self,
        width: int,
        height: int,
        palette: list[tuple[int, int, int]],
        frames: list[list[int]],
        delay_cs: int,
    ) -> bytes:
        color_table = bytearray()
        for index in range(64):
            color_table.extend([
                ((index >> 4) & 0x03) * 255 // 3,
                ((index >> 2) & 0x03) * 255 // 3,
                (index & 0x03) * 255 // 3,
            ])

        def quantized(frame: list[int]) -> list[int]:
            result: list[int] = []
            for pixel in frame:
                red, green, blue = palette[pixel]
                result.append(((red >> 6) << 4) | ((green >> 6) << 2) | (blue >> 6))
            return result

        min_code_size = 6
        gif = bytearray(b"GIF89a")
        gif.extend(width.to_bytes(2, "little"))
        gif.extend(height.to_bytes(2, "little"))
        gif.extend(bytes([0xF5, 0x00, 0x00]))
        gif.extend(color_table)
        gif.extend(b"\x21\xFF\x0BNETSCAPE2.0\x03\x01\x00\x00\x00")

        for frame in frames:
            image_data = self._gif_lzw(quantized(frame), min_code_size)
            blocks = bytearray()
            for offset in range(0, len(image_data), 255):
                chunk = image_data[offset : offset + 255]
                blocks.append(len(chunk))
                blocks.extend(chunk)
            blocks.append(0)

            gif.extend(b"\x21\xF9\x04\x04")
            gif.extend(int(delay_cs).to_bytes(2, "little"))
            gif.extend(b"\xFF\x00")
            gif.extend(b"\x2C\x00\x00\x00\x00")
            gif.extend(width.to_bytes(2, "little"))
            gif.extend(height.to_bytes(2, "little"))
            gif.append(0x00)
            gif.append(min_code_size)
            gif.extend(blocks)

        gif.append(0x3B)
        return bytes(gif)

    def _gif_lzw(self, indices: list[int], min_code_size: int) -> bytes:
        clear = 1 << min_code_size
        end = clear + 1
        dictionary = {(i,): i for i in range(clear)}
        next_code = end + 1
        code_size = min_code_size + 1
        max_code = 1 << code_size
        bit_buffer = 0
        bit_count = 0
        output = bytearray()

        def write_code(code: int):
            nonlocal bit_buffer, bit_count
            bit_buffer |= code << bit_count
            bit_count += code_size
            while bit_count >= 8:
                output.append(bit_buffer & 0xFF)
                bit_buffer >>= 8
                bit_count -= 8

        def reset_dictionary():
            nonlocal dictionary, next_code, code_size, max_code
            dictionary = {(i,): i for i in range(clear)}
            next_code = end + 1
            code_size = min_code_size + 1
            max_code = 1 << code_size

        reset_dictionary()
        write_code(clear)
        current: tuple[int, ...] = ()
        for index in indices:
            candidate = current + (index,)
            if candidate in dictionary:
                current = candidate
                continue
            write_code(dictionary[current])
            if next_code < 4096:
                dictionary[candidate] = next_code
                next_code += 1
                if next_code > max_code and code_size < 12:
                    code_size += 1
                    max_code = 1 << code_size
            else:
                write_code(clear)
                reset_dictionary()
            current = (index,)
        if current:
            write_code(dictionary[current])
        write_code(end)
        if bit_count:
            output.append(bit_buffer & 0xFF)
        return bytes(output)

    def _scan_context(self):
        proc_root = Path("/proc")
        if not proc_root.exists():
            return self._empty_steam_context()

        launch_context = self._scan_steam_launch_context(proc_root)
        if launch_context.get("appId"):
            return launch_context

        for entry in proc_root.iterdir():
            if not entry.name.isdigit():
                continue
            environ_path = entry / "environ"
            try:
                environ = environ_path.read_bytes().decode("utf-8", errors="ignore")
            except OSError:
                continue

            app_id = ""
            for token in environ.split("\0"):
                if token.startswith("SteamAppId="):
                    app_id = token.split("=", 1)[1]
                    break
                if token.startswith("SteamGameId="):
                    app_id = token.split("=", 1)[1]

            if not app_id or app_id == "0":
                continue

            try:
                title = (entry / "comm").read_text(encoding="utf-8", errors="ignore").strip()
            except OSError:
                title = ""
            title = self._steam_app_name(app_id) or title
            return self._steam_context(app_id, title, self._process_started_at(entry), "decky-env")

        return self._empty_steam_context()

    def _empty_steam_context(self):
        return {
            "appId": "",
            "title": "",
            "source": "decky",
            "sessionStartedAt": 0,
            "totalPlaytimeMinutes": 0,
            "running": False,
        }

    def _scan_recent_steam_context(self):
        newest = None
        userdata = self._steam_root().joinpath("userdata")
        for localconfig in userdata.glob("*/config/localconfig.vdf"):
            try:
                text = localconfig.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for match in re.finditer(r'"(\d+)"\s*\{', text):
                app_id = match.group(1)
                block = text[match.end() : match.end() + 1400]
                last_played = re.search(r'"LastPlayed"\s+"(\d+)"', block)
                playtime = re.search(r'"Playtime"\s+"?(\d+)"?', block)
                if not last_played:
                    continue
                candidate = (int(last_played.group(1)), app_id, int(playtime.group(1)) if playtime else 0)
                if newest is None or candidate[0] > newest[0]:
                    newest = candidate
        if newest is None:
            return self._empty_steam_context()
        _, app_id, playtime = newest
        title = self._steam_app_name(app_id) or f"APP {app_id}"
        return {
            "appId": app_id,
            "title": title,
            "source": "steam-recent",
            "sessionStartedAt": 0,
            "totalPlaytimeMinutes": playtime,
            "running": False,
        }

    def _steam_context(self, app_id: str, title: str, session_started_at: float, source: str):
        return {
            "appId": app_id,
            "title": title,
            "source": source,
            "sessionStartedAt": session_started_at,
            "totalPlaytimeMinutes": self._steam_playtime_minutes(app_id),
            "running": True,
        }

    def _scan_steam_launch_context(self, proc_root: Path):
        for entry in proc_root.iterdir():
            if not entry.name.isdigit():
                continue
            try:
                cmdline = entry.joinpath("cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", errors="ignore")
            except OSError:
                continue
            match = re.search(r"SteamLaunch\s+AppId=(\d+)", cmdline)
            if not match:
                continue
            app_id = match.group(1)
            if app_id == "0":
                continue
            title = self._steam_app_name(app_id) or self._title_from_steam_cmdline(cmdline) or "GAME"
            return self._steam_context(app_id, title, self._process_started_at(entry), "steam-launch")
        return self._empty_steam_context()

    def _process_started_at(self, proc_entry: Path) -> float:
        try:
            stat = proc_entry.joinpath("stat").read_text(encoding="utf-8", errors="ignore")
            end = stat.rfind(")")
            fields = stat[end + 2 :].split()
            start_ticks = int(fields[19])
            ticks_per_second = os.sysconf(os.sysconf_names.get("SC_CLK_TCK", "SC_CLK_TCK"))
            uptime = float(Path("/proc/uptime").read_text(encoding="utf-8").split()[0])
            return time.time() - uptime + (start_ticks / ticks_per_second)
        except Exception:
            return 0

    def _title_from_steam_cmdline(self, cmdline: str) -> str:
        marker = "/steamapps/common/"
        if marker not in cmdline:
            return ""
        tail = cmdline.split(marker, 1)[1]
        title = tail.split("/", 1)[0].strip()
        return title.replace("_", " ")

    def _steam_root(self) -> Path:
        return Path(os.environ.get("STEAM_COMPAT_CLIENT_INSTALL_PATH", "/home/deck/.local/share/Steam"))

    def _steam_app_name(self, app_id: str) -> str:
        if not app_id:
            return ""
        for manifest in self._steam_root().joinpath("steamapps").glob(f"**/appmanifest_{app_id}.acf"):
            try:
                text = manifest.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            match = re.search(r'"name"\s+"([^"]+)"', text)
            if match:
                return match.group(1)
        appinfo = self._steam_root().joinpath("appcache", "appinfo.vdf")
        try:
            data = appinfo.read_bytes()
            needle = app_id.encode("ascii")
            position = data.find(needle)
            if position >= 0:
                chunk = data[max(0, position - 192) : position]
                candidates = re.findall(rb"[ -~]{2,120}\x00", chunk)
                for value in reversed(candidates):
                    title = value[:-1].decode("utf-8", errors="ignore").strip()
                    if title and not title.isdigit() and title.lower() not in {"name", "type", "game", "windows"}:
                        return title
        except OSError:
            pass
        return ""

    def _steam_playtime_minutes(self, app_id: str) -> int:
        if not app_id:
            return 0
        userdata = self._steam_root().joinpath("userdata")
        best = 0
        for localconfig in userdata.glob("*/config/localconfig.vdf"):
            try:
                text = localconfig.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            match = re.search(rf'"{re.escape(app_id)}"\s*\{{(.*?)\n\s*\}}', text, re.S)
            if not match:
                continue
            playtime = re.search(r'"Playtime"\s+"?(\d+)"?', match.group(1))
            if playtime:
                best = max(best, int(playtime.group(1)))
        return best

    async def _main(self):
        decky.logger.info("JSAUX PIXEL plugin started")
        asyncio.create_task(self._suspend_monitor())
        try:
            settings = await self.get_display_settings()
            if isinstance(settings.get("displaySettings"), dict):
                settings = settings["displaySettings"]
            active_module = str(settings.get("activeModuleId") or settings.get("active_module_id") or "")
            custom = settings.get("custom", {})
            current_asset = ""
            if isinstance(custom, dict):
                current_asset = str(custom.get("current_asset") or custom.get("currentAsset") or "")
            if active_module.lower() == "playtime":
                await self.send_playtime_monitor()
                decky.logger.info("Playtime monitor resumed on plugin start")
            elif active_module.lower() == "custom" and self._is_chronograph_asset(current_asset):
                await self.send_chronograph_monitor(CHRONOGRAPH_MAX_SECONDS)
                decky.logger.info("Chronograph monitor resumed on plugin start")
        except Exception as exc:
            decky.logger.info(f"Active monitor resume skipped: {exc}")

    async def _unload(self):
        if hasattr(self, "_suspend_process") and self._suspend_process:
            try:
                self._suspend_process.terminate()
            except Exception:
                pass
        self._chronograph_watchdog_generation += 1
        self._stop_legacy_monitor_loops()
        decky.logger.info("JSAUX PIXEL plugin stopped")

    async def _uninstall(self):
        self._remove_companion_desktop_install()
        decky.logger.info("JSAUX PIXEL plugin uninstalled")

    def _remove_companion_desktop_install(self):
        home = Path.home()
        service = home / ".config/systemd/user/jsaux-matrix-hub.service"
        systemctl_env = os.environ.copy()
        systemctl_env.update(
            {
                "HOME": str(home),
                "XDG_RUNTIME_DIR": f"/run/user/{os.getuid()}",
                "DBUS_SESSION_BUS_ADDRESS": f"unix:path=/run/user/{os.getuid()}/bus",
            }
        )
        subprocess.run(
            ["systemctl", "--user", "disable", "--now", "jsaux-matrix-hub.service"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=systemctl_env,
        )
        for path in (
            home / ".local/bin/jsaux-matrix-studio",
            home / ".local/bin/jsaux-matrix-daemon",
            home / ".local/bin/jsaux-matrixlink-uninstall",
            home / ".local/share/applications/jsaux-matrixlink.desktop",
            home / ".local/share/applications/jsaux-matrixlink-uninstall.desktop",
            home / "Desktop/JSAUX PIXEL.desktop",
            home / "Desktop/JSAUX MatrixLink.desktop",
            home / ".local/share/icons/hicolor/scalable/apps/jsaux-matrixlink.svg",
            service,
        ):
            try:
                path.unlink(missing_ok=True)
            except OSError as exc:
                decky.logger.info(f"Companion desktop cleanup skipped for {path}: {exc}")
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=systemctl_env,
        )

    async def _migration(self):
        decky.logger.info("JSAUX PIXEL plugin migration")

    async def suspend(self):
        decky.logger.info("System suspending - turning off display")
        try:
            await self.set_power(False)
        except Exception as err:
            decky.logger.error(f"Error turning off display on suspend: {err}")

    async def resume(self):
        decky.logger.info("System resuming - restoring display")
        try:
            await self.set_power(True)
        except Exception as err:
            decky.logger.error(f"Error restoring display on resume: {err}")

    async def _suspend_monitor(self):
        try:
            self._suspend_process = await asyncio.create_subprocess_exec(
                "stdbuf", "-oL", "dbus-monitor", "--system", "type='signal',interface='org.freedesktop.login1.Manager',member='PrepareForSleep'",
                stdout=asyncio.subprocess.PIPE
            )
            while True:
                line = await self._suspend_process.stdout.readline()
                if not line:
                    break
                line_str = line.decode('utf-8').strip()
                if "boolean true" in line_str:
                    decky.logger.info("System suspending - turning off display")
                    try:
                        await self.set_power(False)
                    except Exception as err:
                        decky.logger.error(f"Error turning off display on suspend: {err}")
                elif "boolean false" in line_str:
                    decky.logger.info("System resuming - restoring display")
                    try:
                        await self.set_power(True)
                    except Exception as err:
                        decky.logger.error(f"Error restoring display on resume: {err}")
        except Exception as e:
            decky.logger.error(f"Suspend monitor crashed: {e}")
